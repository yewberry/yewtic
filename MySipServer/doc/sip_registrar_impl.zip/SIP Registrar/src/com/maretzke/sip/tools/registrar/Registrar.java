/*
 * Project: SIP Registrar - An example SIP Registrar implementing the chapter 10 of 
 * 			RFC 3261 describing the behaviour of a SIP Registrar. The SIP Registrar
 * 			is implemented using SIP Servlet technologies. 
 *
 * File: Registrar.java
 * Author: Michael Maretzke
 * License: Distributable under LGPL license - see terms of license at gnu.org
 * Created: 22nd November 2006, 22:17
 * Version: 1.0
 */
package com.maretzke.sip.tools.registrar;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;

import com.maretzke.sip.tools.DebugSipServlet;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.sip.Address;
import javax.servlet.sip.SipFactory;
import javax.servlet.sip.SipServletRequest;
import javax.servlet.sip.SipServletResponse;
import javax.servlet.sip.Proxy;
import javax.servlet.sip.TooManyHopsException;

import org.apache.commons.lang.StringEscapeUtils;


/**
 * The class Registrar is the actual entry point of all the coding logic around
 * the SIP Registrar. It is the SIP Servlet containing the business logic to
 * parse the incoming messages according to RFC 3261 chapter 10.<br>
 * The Servlet actually deals with the SIP signalling portion of the SIP
 * Registrar. The whole storage and expiration management is outsourced to an
 * implementation of the interface LocationService.<br>
 * <br>
 * In the example presented here, the LocationService implementation
 * (InMemoryLocationService) stores all the relevant registration information in
 * a single physical node, in memory. The contact point between the Registrar
 * and the store is the interface LocationService. To extend the Registrar and
 * make it fault tolerant and distributable it is recommended to improve the
 * capabilities of the storage.<br>
 * <br>
 * Furthermore, the whole example is created with the sole idea in mind of
 * producing an example implementation of the RFC 3261 SIP REGISTER handling. It
 * is not intended to provide production quality code. The Registrar might be a
 * good starting point from functional level - however it is not fine-tuned from
 * code quality and performance perspective. <br>
 * <br>
 * The configuration of the Registrar is done in the sip.xml deployment
 * descriptor.<br>
 * <code><pre>
 *                    	&lt;servlet&gt;
 *                    		&lt;servlet-name&gt;registrar&lt;/servlet-name&gt;
 *                    		&lt;servlet-class&gt;
 *                    			com.maretzke.sip.tools.registrar.Registrar
 *                    		&lt;/servlet-class&gt;
 *                    
 *                    		&lt;init-param&gt;
 *                    			&lt;param-name&gt;
 *                    				Registrar.Domain
 *                    			&lt;/param-name&gt;
 *                    			&lt;param-value&gt;example.de&lt;/param-value&gt;
 *                    		&lt;/init-param&gt;
 *                    
 *                    		&lt;init-param&gt;
 *                    			&lt;param-name&gt;
 *                    				Registrar.MinExpireValue
 *                    			&lt;/param-name&gt;
 *                    			&lt;param-value&gt;10&lt;/param-value&gt;
 *                    		&lt;/init-param&gt;
 *                      &lt;/servlet&gt;
 *                    
 *                    @author Michael Maretzke
 * 
 */
public class Registrar extends DebugSipServlet {

	// unique identifier for this class
	private static final long serialVersionUID = 6548946513L;

	// string to store the implementation of the LocationService implementation.
	// the information is stored actually in the JNDI tree for further
	// reference.
	private final String JNDI_LOCATION_SERVICE = "java:comp/com/maretzke/sip/tools/registrar/locationService";

	// the implementation of the LocationService
	private LocationService locationService;

	// the domain served by this Registrar - stored in the sip.xml descriptor
	private String domain;

	// a reference to the SipFactory used by the Registrar
	private SipFactory sipFactory;

	// the minimum expiration value stored in the sip.xml descriptor
	private long minExpire;

	/**
	 * Initializes the SIP Servlet. Called only through initialization of the
	 * SIP Servlet.
	 * 
	 * @param servletConfig information provided by the application server
	 */
	public void init(ServletConfig servletConfig) throws ServletException {
		// call the parents' init method
		super.init(servletConfig);

		// create a new instance of the registrations' store and store it
		// in the JNDI tree
		locationService = new InMemoryLocationService();

		Context ctx;
		try {
			ctx = new InitialContext();
			ctx.bind(JNDI_LOCATION_SERVICE, locationService);
		} catch (NamingException e) {
			e.printStackTrace();
		}

		// get a reference to the SipFactory
		sipFactory = (SipFactory) getServletContext().getAttribute(SIP_FACTORY);

		// load the domain to be served by this server from the sip.xml
		// descriptor
		domain = getServletConfig().getInitParameter("Registrar.Domain");
		if (domain == null)
			domain = "default";

		// load the minimum expiry value from the sip.xml descriptor
		minExpire = 50;
		minExpire = Long.parseLong(getServletConfig().getInitParameter("Registrar.MinExpireValue"));

		trace(INFO, "Registrar initialized. Serving domain: " + domain + ", minimum Expire time is set to: " + minExpire);
		locationService = null;
	}

	/**
	 * Destroys the SIP Servlet. Called by the application server environment.
	 */
	public void destroy() {
		// lookup the LocationService from JNDI
		locationService = getLocationService();

		// allow the locationService implementation to gracefully shutdown
		locationService.cleanUp();
		trace(INFO, "Registrar is shutting down now.");
	}

	/**
	 * Serves incoming REGISTER messages. All relevant business logic for a SIP
	 * Registrar can be found in this method.
	 * 
	 * @param req the SipServletRequest generated by the application server
	 */
	public void doRegister(SipServletRequest req) throws ServletException, IOException {
		// create a new Registration object from the received request
		Registration reg = new Registration(req, sipFactory);

		// lookup the LocationService from JNDI
		locationService = getLocationService();

		// do some traces
		trace(INFO, "locationService = " + locationService);
		trace(INFO, "Request domain = " + reg.getDomain());
		trace(INFO, "Request domain is valid? - " + reg.isDomainValid());
		trace(INFO, "Request CSeq = " + reg.getCSeq());
		trace(INFO, "Request Call-ID = " + reg.getCallId());
		trace(INFO, "Is the registration valid? - " + reg.isValid());
		trace(INFO, "Is contact list empty? - " + reg.getContacts().isEmpty());
		trace(INFO, "Is wildcard request? - " + reg.hasWildcard());

		// check if the request is valid; if not, return a 400 error message to
		// the sender of the original SIP message
		if (!reg.isValid()) {
			sendErrorResponse(req, 400, reg.getErrorMsg());
			return;
		}

		// check if the domain is valid e.g. contains "userinfo" and "@" element
		// - which is forbidden
		if (!reg.isDomainValid()) {
			sendErrorResponse(req, 400, "Invalid domain format. The \'userinfo\' and \'@\' components of the SIP URI MUST NOT be present.");
			return;
		}

		// check if the request is for the domain of this registrar
		if (domain.compareToIgnoreCase(reg.getDomain()) != 0) {
			trace(INFO, "Not serving the requests' domain. Proxying the request.");
			// proxy the request
			try {
				Proxy proxy = req.getProxy(true);
				proxy.setRecordRoute(false);
				proxy.setRecurse(true);
				proxy.setSupervised(false);
				proxy.proxyTo(req.getRequestURI());
			} catch (TooManyHopsException e) {
				e.printStackTrace();
				throw new ServletException(e);
			}
			return;

		}

		// process Require header as in 3261 section 8.2.2
		if (reg.containsRequire()) {
			SipServletResponse resp = createErrorResponse(req, 420, "Bad Extension. Require header not supported.");
			resp.addHeader("Unsupported", reg.getRequire());
			resp.send();
			return;
		}

		// The following steps in the RFC 3261 are omitted:
		// 1) authenticate UAC?
		// 2) is user authorized to modify binding?
		// These steps need to be included in a proper RFC 3261 compliant
		// implementation.
		// For the purpose of this example it is assumed that the UAC is
		// authenticated and
		// the user is allowed to modify the binding.

		// check if the AOR domain is valid for the domain
		String aor = reg.getAOR().toString();
		String aor_domain = aor.substring(aor.indexOf('@') + 1);
		if (domain.compareToIgnoreCase(aor_domain) != 0) {
			trace(INFO, "AOR is not valid for this domain.");
			sendErrorResponse(req, 404, "Not Found - AOR is not valid for this domain.");
			return;
		}

		// unescape the AOR
		aor = StringEscapeUtils.unescapeJava(aor);

		trace(INFO, "Registration valid? --> " + reg.isValid());

		// check if the minimum expires header is under-run; if so, generate a
		// 423 message containing the minimal expire value for this Registrar
		if ((reg.getMinExpire() > 0) && (reg.getMinExpire() < 3600) && (reg.getMinExpire() < minExpire)) {
			SipServletResponse resp = createErrorResponse(req, 423, "Interval Too Brief.");
			resp.addHeader("Min-Expires", "" + minExpire);
			resp.send();
			return;
		}

		// check if there's already a binding for the AOR
		Registration binding = locationService.getBindings(aor);
		if (binding != null) {
			trace(INFO, "binding found!");
			// check if the call-id is the same as from the previous binding
			if (binding.getCallId().compareTo(reg.getCallId()) != 0) {
				// different --> update binding information
				locationService.updateBinding(aor, reg);
			} else if (binding.getCSeq() < reg.getCSeq())
				// the same, but cseq is increased --> update binding
				// information
				locationService.updateBinding(aor, reg);
			else {
				// otherwise, abort request since it's invalid
				sendErrorResponse(req, 400, "Invalid request.");
				return;
			}
		} else {
			// consider adding the binding only if it's not a wildcard
			// and the contact list is not empty
			if (!reg.hasWildcard() && !reg.getContacts().isEmpty())
				locationService.addBinding(aor, reg);
		}

		// create the final response
		SipServletResponse ok = req.createResponse(200);
		// add the current date
		SimpleDateFormat sdf = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss z", Locale.ENGLISH);
		ok.setHeader("Date", sdf.format(new Date()));

		// add all registered bindings
		Registration bindings = (Registration) locationService.getBindings(aor);
		if (bindings != null) {
			Iterator it = bindings.getContacts().iterator();
			while (it.hasNext()) {
				Contact contact = (Contact) it.next();
				Address address = sipFactory.createAddress(contact.getContact());
				// RFC 3261 chapter 10.3 clause 8 is not too explicit about the
				// actual calculation of the "expires" parameter to be added to
				// the 200 OK:
				// "Each Contact value MUST feature an "expires"
				// parameter indicating its expiration interval chosen by the
				// registrar."
				// It could be that the original delivered interval - e.g. 3600
				// (1 hour) - should be returned (A) or the remaining validity
				// of the contact at this SIP Registrar should be returned (B)
				//
				// I decided to implement option (B) and comment option (A)
				// OPTION (A):
				// address.setExpires(contact.getExpire());
				// OPTION (B):
				long expiry = (contact.getTimeStamp() + (contact.getExpire() * 1000) - System.currentTimeMillis()) / 1000;
				address.setExpires(Math.round(expiry));

				if (contact.getQ() != -1)
					address.setQ(contact.getQ());

				ok.addHeader("Contact", address.toString());
			}
		}

		// and send the response
		ok.send();
	}

	/**
	 * Lookup the implementation of the interface LocationService in the JNDI
	 * environment of the application server.
	 * 
	 * @return the implementation of the interface LocationService
	 */
	private LocationService getLocationService() {
		Context ctx;
		try {
			ctx = new InitialContext();
			return (LocationService) ctx.lookup(JNDI_LOCATION_SERVICE);
		} catch (NamingException e) {
			e.printStackTrace();
			return null;
		}
	}
}
