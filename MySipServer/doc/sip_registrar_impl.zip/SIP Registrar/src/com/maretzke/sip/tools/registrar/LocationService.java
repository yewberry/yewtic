/*
 * Project: SIP Registrar - An example SIP Registrar implementing the chapter 10 of 
 * 			RFC 3261 describing the behaviour of a SIP Registrar. The SIP Registrar
 * 			is implemented using SIP Servlet technologies. 
 *
 * File: LocationService.java
 * Author: Michael Maretzke
 * License: Distributable under LGPL license - see terms of license at gnu.org
 * Created: 22nd November 2006, 22:17
 * Version: 1.0
 */
package com.maretzke.sip.tools.registrar;

import java.util.Collection;

/**
 * The interface LocationService is the information bridge between the
 * Registrar's SIP processing logic and the actual information storage. The
 * interface offers all needed methods from the Registrar's perspective to
 * handle the storage of the collected information / bindings. <br>
 * The interface allows for various implementations of the actual storage of the
 * binding information - either in a single node in memory or in a database or
 * ...
 * 
 * @author Michael Maretzke
 */
public interface LocationService {

	/**
	 * Adds a registration to the store.
	 * 
	 * @param aor the Address Of Record (aor) of this contact
	 * @param binding the Registration object to be associated with this AOR
	 */
	public void addBinding(String aor, Registration binding);

	/**
	 * Updates the binding stored for a given AOR.
	 * 
	 * @param aor the Address Of Record to update
	 * @param binding the Registration object containing the new information
	 */
	public void updateBinding(String aor, Registration binding);

	/**
	 * Returns all Bindings in a Collection.
	 * 
	 * @return returns a Collection of all stored bindings in the store
	 */
	public Collection getAllBindings();

	/**
	 * Allows for resource clean up prior to shut-down.
	 */
	public void cleanUp();

	/**
	 * Clears the storage area with all contained registrations.
	 */
	public void clearAllBindings();

	/**
	 * Returns the stored registration for a given AOR.
	 * 
	 * @param aor the Address Of Record to be looked for
	 * @return the Registration object stored under the requested AOR
	 */
	public Registration getBindings(String aor);
}
