/*
 * Project: SIP Registrar - An example SIP Registrar implementing the chapter 10 of 
 * 			RFC 3261 describing the behaviour of a SIP Registrar. The SIP Registrar
 * 			is implemented using SIP Servlet technologies. 
 *
 * File: QueryLocationService.java
 * Author: Michael Maretzke
 * License: Distributable under LGPL license - see terms of license at gnu.org
 * Created: 11th July 2007, 22:17
 * Version: 1.0
 */
package com.maretzke.sip.tools.registrar;

import javax.servlet.sip.URI;

/**
 * The interface QueryLocationService is the information bridge between the
 * Proxy working on incoming requests and the LocationService. It offers only
 * the capability to query the LocationService with a method expecting the AOR
 * and returning the Registration for proper proxying of the request.
 * 
 * @author Michael Maretzke
 */
public interface QueryLocationService {

	/**
	 * Looksup the binding information for a specific AOR.
	 * 
	 * @param aor the Address Of Record (aor) to lookup
	 * @return binding the Registration object to be associated with this AOR
	 */
	public Registration lookupBinding(String aor);

}
