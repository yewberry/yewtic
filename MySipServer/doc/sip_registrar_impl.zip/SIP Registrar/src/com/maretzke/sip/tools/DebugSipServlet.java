/*
 * Project: SIP Registrar - An example SIP Registrar implementing the chapter 10 of 
 * 			RFC 3261 describing the behaviour of a SIP Registrar. The SIP Registrar
 * 			is implemented using SIP Servlet technologies. 
 *
 * File: DebugSipServlet.java
 * Author: Michael Maretzke
 * License: Distributable under LGPL license - see terms of license at gnu.org
 * Created: 22nd November 2006, 22:17
 * Version: 1.0
 */
package com.maretzke.sip.tools;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.sip.SipServlet;
import javax.servlet.sip.SipServletRequest;
import javax.servlet.sip.SipServletResponse;

/**
 * The class DebugSipServlet is used as a generic and basic implementation of a SIP
 * Servlet which allows certain debug settings.<br>
 * <br>
 * The servlet defines various levels of granularity for debug messages. It further
 * more introduces several trace methods and contains some convenience methods for 
 * Response generation.<br>
 * <br> 
 * Configuration of the SIP Servlet is done in the Sip.xml deployment descriptor.<br> 
 * <code><pre>
 * &lt;context-param&gt;
 *    &lt;param-name&gt;
 *       com.maretzke.sip.tools.registrar.Registrar.TraceLevel
 *    &lt;/param-name&gt;
 *    &lt;param-value&gt;all&lt;/param-value&gt;
 * &lt;/context-param&gt;
 * </pre></code>
 * <br>
 * The &lt;param-name&gt; parameter is composed of the class name and ".TraceLevel".<br> 
 * 
 * @author Michael Maretzke
 */

public class DebugSipServlet extends SipServlet {
	// globally unique ID for serialization
	private static final long serialVersionUID = 6541268653L;

	// various levels of granularity
	public static final int ALL = 16;
	public static final int INFO = 8;
	public static final int DEBUG = 4;
	public static final int WARNING = 2;
	public static final int ERROR = 1;
	public static final int NONE = 0;

	// the configured trace granularity
	private int traceLevel;

    /**
     * Invoked by the SIP Servlet container to initialize the SIP Servlet. 
     * 
     * @param servletConfig handed over by the container containing the SIP Servlet configuration
     */	
	public void init(ServletConfig servletConfig) throws ServletException {
		super.init(servletConfig);

		// resolve the String representation of the trace level to integer 
		String trace = servletConfig.getServletContext().getInitParameter(getClass().getName() + ".TraceLevel");

		if (trace == null) traceLevel = NONE;
		else traceLevel = parseTraceLevel(trace);
	}

    /**
     * Method to handle SIP Requests. Overwritten to trace the actual request to stdout.
     * Invoked by the SIP Servlet. 
     * 
     * @param req the SIP request
     */	
	protected void doRequest(SipServletRequest req) throws ServletException, IOException {
		trace(INFO, req, "doRequest()");
		super.doRequest(req);
	}

    /**
     * Method to handle SIP Responses. Overwritten to trace the actual response to stdout.
     * Invoked by the SIP Servlet. 
     * 
     * @param resp the SIP response
     */	
	protected void doResponse(SipServletResponse resp) throws ServletException, IOException {
		trace(INFO, resp, "doResponse()");
		super.doResponse(resp);
	}

	
    /**
     * Helper method to ease the creation and sending 
     * of SIP error messages.
     * 
     * @param req the SIP request
     * @param code the error code to send back in the SIP message
     * @param msg the message to be contained in the SIP message
     */
	protected void sendErrorResponse(SipServletRequest req, int code, String msg) throws IOException {
		SipServletResponse resp = req.createResponse(code, msg);
		trace(INFO, resp, "sendErrorResponse()");
		resp.send();
	}

    /**
     * Helper method to ease the creation of SIP error messages.
     * 
     * @param req the SIP request
     * @param code the error code to send back in the SIP message
     * @param msg the message to be contained in the SIP message
     * @return the generated response object containing the error message
     */
	protected SipServletResponse createErrorResponse(SipServletRequest req, int code, String msg) {
		SipServletResponse resp = req.createResponse(code, msg);
		trace(INFO, resp, "sendErrorResponse()");
		return resp;
	}

    /**
     * Trace method to print a SIP request to stdout.
     * 
     * @param level the level of granularity to use for this trace
     * @param req the SIP request to print
     * @param msg the message to be contained in the trace
     */
	private void trace(int level, SipServletRequest req, String message) {
		trace(level, message + " [" + req.getMethod() + "]");
		trace(level, message + " URI[" + req.getRequestURI() + "]");
		trace(level, message + " From[" + req.getFrom() + "]");
		trace(level, message + " To[" + req.getTo() + "]");
		trace(level, message + " -------------------------------------------------");
	}

    /**
     * Trace method to print a SIP response to stdout.
     * 
     * @param level the level of granularity to use for this trace
     * @param resp the SIP response to print
     * @param msg the message to be contained in the trace
     */
	private void trace(int level, SipServletResponse resp, String message) {
		trace(level, message + " [" + resp.getStatus() + "]");
		trace(level, message + " Code[" + resp.getReasonPhrase() + "]");
		trace(level, message + " From[" + resp.getFrom() + "]");
		trace(level, message + " To[" + resp.getTo() + "]");
		trace(level, message + " -------------------------------------------------");
	}

    /**
     * Trace method to print a message to stdout or a log file.
     * 
     * @param level the level of granularity to use for this trace
     */
	public void trace(int level, String message) {
		if (level <= traceLevel) {
			System.out.println(getClass().getName() + " --- " + message);
			// log(getClass().getName() + " - " + message);
		}
	}

    /**
     * Helper method to convert the string granularity to the integer
     * representaton.
     * 
     * @param trace the string describing the trace granularity
     * @return the integer representation of the trace granularity
     */
	private int parseTraceLevel(String trace) {
		trace = trace.toLowerCase();
		if (trace.compareTo("all") == 0)
			return ALL;
		if (trace.compareTo("info") == 0)
			return INFO;
		if (trace.compareTo("debug") == 0)
			return DEBUG;
		if (trace.compareTo("warning") == 0)
			return WARNING;
		if (trace.compareTo("error") == 0)
			return ERROR;
		return NONE;
	}
}
