/*
 * Project: SIP Registrar - An example SIP Registrar implementing the chapter 10 of 
 * 			RFC 3261 describing the behaviour of a SIP Registrar. The SIP Registrar
 * 			is implemented using SIP Servlet technologies. 
 *
 * File: Contact.java
 * Author: Michael Maretzke
 * License: Distributable under LGPL license - see terms of license at gnu.org
 * Created: 22nd November 2006, 22:17
 * Version: 1.0
 */
package com.maretzke.sip.tools.registrar;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * The class Contact represents all relevant information of a SIP REGISTER message with 
 * respect to the contact header information.<br>
 * 
 * @author Michael Maretzke
 */
public class Contact implements Serializable {
	// globally unique ID for serialization
	private static final long serialVersionUID = 654657984L;

	// stores the expires value associated to this contact
	// expires is stored as found in the SIP message; the metric is seconds
	private int expires;
	// the contact string as found in the SIP message
	private String contact;
	// the "q" parameter defines the relative prioritization of the contact
	// "q" is stored as found in the SIP message
	private float q = -1;
	// the timestamp during creation of the contact
	private long timestamp;
	// the Address Of Record to which this contact belongs to
	private String aor;
	
	
    /**
	 * Standard constructor to create a contact object.
	 * 
	 * @param aor the Address Of Record (aor) of this contact
	 * @param contact the contact information as found in the SIP message
	 * @param expires the expires information as found in the SIP message
	 *            (seconds)
	 * @param q the parameter "q" as found in the SIP message
	 */	
	public Contact (String aor, String contact, int expires, float q) {
		this.aor = aor;
		this.contact = contact;
		this.expires = expires;
		this.q = q;
		// get the timestamp during creation of the contact object; this will
		// be used for expiration calculations
		this.timestamp = System.currentTimeMillis();		
	}

    /**
     * Access the Address Of Record (aor) of this contact.
     * 
     * @return aor of this contact
     */
	public String getAor() {
		return this.aor;
	}

    /**
     * Access the value of parameter "q" for this contact.
     * 
     * @return value of parameter "q"
     */
	public float getQ() {
		return this.q;
	}
	
    /**
     * Access expires value of this contact. In SIP messages the expires value is
     * measured in seconds.
     * 
     * @return expires value
     */
	public int getExpire() {
		return this.expires;
	}
	
    /**
     * Access the contact information.
     * 
     * @return contact information
     */	
	public String getContact() {
		return this.contact;
	}
	
     /**
      * Set the new expires information for this contact and update the timestamp
      * information for correct calculation of expire time.
      * 
      * @param expires the new value of expires (also in seconds)
      */
     public void updateExpires(int expires) {
		this.timestamp = System.currentTimeMillis();
		this.expires = expires;
	}

     /**
      * Access timestamp.
      * 
      * @return timestamp of the creation / update of the object
      */
     public long getTimeStamp() {
		return timestamp;
	}
	
     /**
      * Helper method to print the contact information in a readable format.
      * 
      * @return String representation of this contact
      */
    public String toString() {
		SimpleDateFormat sdf = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss z", Locale.ENGLISH);
		return "[" + sdf.format(new Date(timestamp + expires * 1000)) + " | " + contact + ", " + expires + ", " + q + " ]"; 
	}	
}
