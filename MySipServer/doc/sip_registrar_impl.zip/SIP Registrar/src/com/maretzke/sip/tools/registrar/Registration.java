/*
 * Project: SIP Registrar - An example SIP Registrar implementing the chapter 10 of 
 * 			RFC 3261 describing the behaviour of a SIP Registrar. The SIP Registrar
 * 			is implemented using SIP Servlet technologies. 
 *
 * File: Registration.java
 * Author: Michael Maretzke
 * License: Distributable under LGPL license - see terms of license at gnu.org
 * Created: 22nd November 2006, 22:17
 * Version: 1.0
 */
package com.maretzke.sip.tools.registrar;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.ListIterator;

import javax.servlet.sip.Address;
import javax.servlet.sip.ServletParseException;
import javax.servlet.sip.SipFactory;
import javax.servlet.sip.SipServletRequest;

import javax.servlet.sip.URI;

public class Registration {
	// default expiration value is 3600 (seconds) as proposed by the RFC 3261
	private int DEFAULT_EXPIRE = 3600;

	// stores the Call-ID SIP header - e.g. "1-4444@192.168.178.200"
	private String callId;

	// stores the CSeq SIP header - e.g. "1"
	// the cseq contains only the long value and strips off the SIP method -
	// e.g. REGISTER
	private long cseq;

	// stores the Address Of Record - e.g. "sip:ernestoe@example.de"
	// the aor is extracted from the SIP To header
	private URI aor;

	// stores the domain - e.g. "example.de"
	// the domain is extracted from the SIP URI
	// e.g. "REGISTER sip:example.de SIP/2.0"
	private String domain;

	// stores the value of the SIP header Require
	private String require;

	// stores the various contacts for the aor
	private ArrayList contacts;

	// stores the value of the SIP header Expires
	private int expires;

	// needed for mathematical calculations of the minimum expires value
	private int minexpires = Integer.MAX_VALUE;

	// indicates if the REGISTER message sent contains a wildcard REGISTER
	private boolean wildcard = false;

	// indicates if the REGISTER message is a valid SIP REGISTER
	// according to RFC 3261 rules
	private boolean valid = true;

	// error message if the request is invalid
	private String message_400 = "Invalid request.";

	/**
	 * Returns the error message. This method returns only meaningful
	 * information if the request is invalid
	 * 
	 * @return the customized error message for a 400 answer
	 */
	public String getErrorMsg() {
		return message_400;
	}

	/**
	 * The default constructor is disabled. Please use the constructor
	 * Registration(SipServletRequest, SipFactory).
	 */
	private Registration() {
	}

	/**
	 * The constructor parses the received REGISTER message and performs
	 * syntactial and semantic checks during the parsing process. Furthermore,
	 * it stores the information parsed from the received SIP message into the
	 * objects' attributes.
	 * 
	 * @param req the SipServletRequest of the received REGISTER message
	 * @param sipFactory the SipFactory used in the context of the received
	 *            request
	 */
	public Registration(SipServletRequest req, SipFactory sipFactory) {
		// extract the aor
		aor = req.getTo().getURI();

		// get the expires value and set it either to the request's SIP header
		// "Expires" value or to the DEFAULT_EXPIRE value (3600)
		expires = req.getExpires();
		if (expires == -1)
			expires = DEFAULT_EXPIRE;

		// parse the various contacts present
		contacts = new ArrayList();
		ListIterator it = req.getHeaders("Contact");
		while (it.hasNext()) {
			Address contact;
			try {
				contact = sipFactory.createAddress((String) it.next());

				// extract the relative importance of the binding
				float q = (contact.getParameter("q") != null)?(Float.parseFloat(contact.getParameter("q"))):(-1f);

				// determine if the contact is a wildcard contact ("*")
				if (contact.isWildcard())
					wildcard = true;
				else {
					// set the expires value of this specific contact
					// information
					int contact_expires = contact.getExpires();
					if (contact_expires != -1) {
						minexpires = Math.min(minexpires, contact.getExpires());
					} else {
						contact_expires = expires;
						minexpires = Math.min(minexpires, expires);
					}
					// add the contact to the binding
					contacts.add(new Contact(aor.toString(), contact.getURI().toString(), contact_expires, q));
				}
			} catch (ServletParseException e) {
				e.printStackTrace();
			}
		}
		// check the validity of the request
		if (wildcard & (contacts.size() > 1))
			valid = false;
		if (wildcard & (expires != 0))
			valid = false;

		// dump the contacts to the log
		System.out.println("CONTACT == " + contacts);

		// extract the domain
		String uri = req.getRequestURI().toString();
		domain = uri.substring(uri.indexOf(':') + 1);

		// store the call-id
		callId = req.getCallId();

		// extract the call sequence
		String cs_str = req.getHeader("CSeq");
		if (cs_str == null) {
			valid = false;
			message_400 = "Invalid request: Missing Header CSeq.";
		} else
			// extract the SIP method from the cseq "1 REGISTER"
			cseq = Long.parseLong(cs_str.substring(0, cs_str.indexOf(' ')));

		// store the require parameters
		require = req.getHeader("Require");
	}

	/**
	 * Returns the validity of the request.
	 * 
	 * @return true if valid; false if invalid
	 */
	public boolean isValid() {
		return valid;
	}

	/**
	 * Returns true or false if the REGISTER request contains "*" wildcards in
	 * the contact list.
	 * 
	 * @return true if wildcards are present; false if not
	 */
	public boolean hasWildcard() {
		return wildcard;
	}

	/**
	 * Returns the contacts associated with the AOR stored in this Registration.
	 * The information is returned as a Collection.
	 * 
	 * @return contacts associated with the AOR
	 */
	public Collection getContacts() {
		return contacts;
	}

	/**
	 * Checks if the associated list of contacts is empty. A Registration
	 * without any contacts is of no value and does only consume resources.
	 * Contacts may expire since they have individual expire dates and so, the
	 * Registration object may carry an empty list of contacts.
	 * 
	 * @return true if the list of contacts is still populated; false if not
	 */
	public boolean hasContact() {
		return !contacts.isEmpty();
	}

	/**
	 * Returns the AOR.
	 * 
	 * @return the AOR of the Registration
	 */
	public URI getAOR() {
		return aor;
	}

	/**
	 * Returns the information of the Require header.
	 * 
	 * @return require header information
	 */
	public String getRequire() {
		return require;
	}

	/**
	 * Returns if the Registration contains a require header or not.
	 * 
	 * @return true if require is present; false if not
	 */
	public boolean containsRequire() {
		return (require != null) ? true : false;
	}

	/**
	 * Returns the domain of the Registration.
	 * 
	 * @return the domain of the Registration.
	 */
	public String getDomain() {
		return domain;
	}

	/**
	 * Returns the call-id of the Registration.
	 * 
	 * @return call-id of the Registration
	 */
	public String getCallId() {
		return callId;
	}

	/**
	 * Returns the CSeq of the Registration.
	 * 
	 * @return cseq of the Registration
	 */
	public long getCSeq() {
		return cseq;
	}

	/**
	 * Checks the validity of the domain of this Registration.
	 * 
	 * @return true if the domain contains a '@'; false if not
	 */
	public boolean isDomainValid() {
		return (domain.indexOf('@') == -1) ? true : false;
	}

	/**
	 * Returns the minimum expiration value of the Registration.
	 * 
	 * @return minimum expiration of Registration
	 */
	public int getMinExpire() {
		return minexpires;
	}

	/**
	 * Dumps the Registration to a string for logging and debugging purposes.
	 */
	public String toString() {
		String s = "[AOR]: " + aor + "\n" + "callID: " + callId + " | CSEQ " + cseq + "\n" + "Contacts: \n  ";

		Iterator it = contacts.iterator();
		while (it.hasNext())
			s += (Contact) it.next() + "\n  ";

		return s;
	}
}
