/*
 * Project: SIP Registrar - An example SIP Registrar implementing the chapter 10 of 
 * 			RFC 3261 describing the behaviour of a SIP Registrar. The SIP Registrar
 * 			is implemented using SIP Servlet technologies. 
 *
 * File: InMemoryLocationStore.java
 * Author: Michael Maretzke
 * License: Distributable under LGPL license - see terms of license at gnu.org
 * Created: 22nd November 2006, 22:17
 * Version: 1.0
 */
package com.maretzke.sip.tools.registrar;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;

/**
 * The class InMemoryLocationStore acts as a container to manage bindings in a
 * HashMap and a list of soon-to-expire bindings in parallel. Especially, the
 * synchronization of the two lists is in focus of the store. The store serves
 * as an implementation for InMemoryLocationService and is a simple
 * non-distributable and non-failure safe implementation for pure demo purposes.
 * It's also not fine- tuned for high-performance.<br>
 * However, the InMemoryLocationStore is exactly the place which needs to be
 * implemented in a distributable and performant way to allow for replication
 * and high-performance.
 * 
 * @author Michael Maretzke
 */
public class InMemoryLocationStore implements Comparator {
	// the map of bindings - key is AOR, object is the Registration object
	private HashMap bindings;

	// a sorted list of soon-to-expire bindings
	private ArrayList expires;

	/**
	 * Standard constructor creates the bindings map and the expires list.
	 */
	public InMemoryLocationStore() {
		expires = new ArrayList();
		bindings = new HashMap();
	}

	/**
	 * Works on both lists, on the bindings and the expire list.
	 */
	public void clear() {
		bindings.clear();
		expires.clear();
	}

	/**
	 * Removes the aor both from the bindings and the expires list
	 * 
	 * @param aor the Address Of Record (aor) to remove
	 */
	public void removeBinding(String aor) {
		bindings.remove(aor);
		Iterator it = expires.iterator();
		while (it.hasNext()) {
			Contact c = (Contact) it.next();
			if (c.getAor().compareTo(aor) == 0) {
				it.remove();
			}
		}
	}

	/**
	 * Adds the binding to both lists, the bindings and the expires list
	 * 
	 * @param aor the Address Of Record (aor) to add
	 * @param binding the binding information to add
	 */
	public void addBinding(String aor, Registration binding) {
		bindings.put(aor, binding);
		// add all the various contact's expire information to the expires list
		Iterator it = binding.getContacts().iterator();
		while (it.hasNext()) {
			expires.add((Contact) it.next());
		}
		// always keep the expires list sorted
		Collections.sort(expires, this);
	}

	/**
	 * Adds a specific contact information to a given AOR.
	 * 
	 * @param aor the Address Of Record (aor) of interest
	 * @param contact the Contact object containing new contact information for
	 *            the aor
	 */
	public void addContact(String aor, Contact contact) {
		Registration reg = (Registration) bindings.get(aor);
		reg.getContacts().add(contact);
		expires.add(contact);
		// always keep the expires list sorted
		Collections.sort(expires, this);
	}

	/**
	 * Expries the bindings with an outdated timestamp.
	 * 
	 * @param timestamp the current time in milliseconds
	 */
	public void expireBindings(long timestamp) {
		Iterator ite = expires.iterator();
		while (ite.hasNext()) {
			Contact c = (Contact) ite.next();
			if (timestamp >= c.getTimeStamp() + c.getExpire() * 1000) {
				Registration binding = (Registration) bindings.get(c.getAor());
				// remove contact from bindings
				binding.getContacts().remove(c);
				// remove whole registration if contacts are empty
				packBindings(c.getAor());
				// remove the contact from expires list
				ite.remove();
			} else
				// investigate only those contacts in the beginning of the
				// sorted list of expiring contacts
				break;
		}

	}

	/**
	 * Returns the bindings for a given AOR.
	 * 
	 * @param aor the Address Of Record (aor) of interest
	 * @return the associated Registration for the AOR
	 */
	public Registration getBindings(String aor) {
		return (Registration) bindings.get(aor);
	}

	/**
	 * Returns a Collection of all stored bindings.
	 * 
	 * @return Collection of bindings
	 */
	public Collection getAllBindings() {
		return bindings.values();
	}

	/**
	 * The method is needed to allow the correct sorting of contacts according
	 * to their expiry time. The method implements the interface Comparator.
	 * 
	 * @param obj1 first object to compare
	 * @param obj2 second object to compare
	 * @return -1 if obj1 < obj2; 0 if obj1 == obj2; +1 if obj1 > obj2
	 */
	public int compare(Object obj1, Object obj2) {
		// returns -1 if obj1 < obj2
		// returns 0 if obj1 == obj2
		// returns +1 if obj1 > obj2

		Contact con1 = (Contact) obj1;
		Contact con2 = (Contact) obj2;

		long con1ts = con1.getTimeStamp() + con1.getExpire() * 1000;
		long con2ts = con2.getTimeStamp() + con2.getExpire() * 1000;

		if (con1ts < con2ts)
			return -1;
		else if (con1ts > con2ts)
			return 1;
		else if (con1ts == con2ts)
			return 0;

		return 0;
	}

	/**
	 * Dumps the whole InMemoryLocationStore into a printable dump.
	 * 
	 * @return String version of the InMemoryLocationStore.
	 */
	public String toString() {
		String s = "Bindings: \n";
		Iterator itb = bindings.values().iterator();
		int i = 1;
		while (itb.hasNext()) {
			Registration r = (Registration) itb.next();
			s += i++ + ": " + r + "\n";
		}

		s += "Expires: \n";
		Iterator ite = expires.iterator();
		i = 1;
		while (ite.hasNext()) {
			Contact c = (Contact) ite.next();
			s += i++ + ": " + c + "\n";
		}
		return s;
	}

	/**
	 * Pack the list of Bindings - if the contacts list for a registration is
	 * empty, the whole registration needs to be removed.
	 * 
	 * @param aor the Address Of Record (aor) to pack
	 */
	private void packBindings(String aor) {
		Registration binding = getBindings(aor);
		if (binding.getContacts().isEmpty())
			bindings.remove(aor);
	}
}
