/*
 * Project: SIP Registrar - An example SIP Registrar implementing the chapter 10 of 
 * 			RFC 3261 describing the behaviour of a SIP Registrar. The SIP Registrar
 * 			is implemented using SIP Servlet technologies. 
 *
 * File: InMemoryLocationService.java
 * Author: Michael Maretzke
 * License: Distributable under LGPL license - see terms of license at gnu.org
 * Created: 22nd November 2006, 22:17
 * Version: 1.0
 */
package com.maretzke.sip.tools.registrar;

import java.util.Collection;
import java.util.Iterator;
import java.util.Timer;
import java.util.TimerTask;

/**
 * The class InMemoryLocationService implements the interface LocationService
 * and serves as the storage for registrations. The InMemoryLocationService is a
 * very simple exemplatory implementation of a registrar database. The demo
 * implementation does store information only locally on one single physical
 * host, the information is not distributed and it is not optimized for
 * performance in any ways.<br>
 * InMemoryLocationService offers the interfaces described in LocationService
 * and maps them to the InMemoryLocationStore. InMemoryLocationService operates
 * a timer every 5 seconds which screens the registrations to identify expired
 * registrations.<br>
 * 
 * @author Michael Maretzke
 */
public class InMemoryLocationService implements LocationService, QueryLocationService {

	// the frequency of the timer in ms
	private final long TIMER_FREQ = 5000;

	// the store where the registrations are stored in
	private InMemoryLocationStore store;

	// the timer to watch the expiry list
	private Timer timer;

	/**
	 * The IMLSTimerTask runs every 5 seconds through the list of registrations
	 * and expires those bindings which need to expire. Furthermore, it dumps
	 * the whole list of bindings into the console.<br>
	 * 
	 * @author Michael Maretzke
	 */
	private class IMLSTimerTask extends TimerTask {
		public void run() {
			System.out.println("--------------------------------------");
			System.out.println(InMemoryLocationService.this.store);
			System.out.println("--------------------------------------");

			store.expireBindings(System.currentTimeMillis());
		}
	}

	/**
	 * Standard constructor to create an InMemoryLocationService object. It
	 * creates a store and a timer to watch the registrations.
	 */
	public InMemoryLocationService() {
		store = new InMemoryLocationStore();
		timer = new Timer();
		timer.schedule(new IMLSTimerTask(), TIMER_FREQ, TIMER_FREQ);
	}

	/**
	 * Clears the storage area with all contained registrations.
	 */
	public void clearAllBindings() {
		store.clear();
	}

	/**
	 * Adds a registration to the store.
	 * 
	 * @param aor the Address Of Record (aor) of this contact
	 * @param binding the Registration object to be associated with this AOR
	 */
	public void addBinding(String aor, Registration binding) {
		store.addBinding(aor, binding);
	}

	/**
	 * Returns the stored registration for a given AOR.
	 * 
	 * @param aor the Address Of Record to be looked for
	 * @return the Registration object stored under the requested AOR
	 */
	public Registration getBindings(String aor) {
		return store.getBindings(aor);
	}

	/**
	 * Updates the binding stored for a given AOR.
	 * 
	 * @param aor the Address Of Record to update
	 * @param binding the Registration object containing the new information
	 */
	public void updateBinding(String aor, Registration binding) {

		// if the registration contains a wildcard "*" it has to be removed from
		// the store
		if (binding.hasWildcard()) {
			store.removeBinding(aor);
			return;
		}

		// the next code segments simply dumps the information of the
		// registration to the console
		System.out.println("########################################");
		System.out.println("AOR to update = " + aor);
		System.out.println("Binding = " + binding);
		System.out.println("Contacts = ");

		Iterator itb = binding.getContacts().iterator();
		int i = 1;
		while (itb.hasNext()) {
			Contact c = (Contact) itb.next();
			System.out.println(i++ + ": " + c);
		}
		System.out.println("########################################");

		// now, we need to search the stored bindings of AOR to see if the
		// contacts received in the latest registration needs to be added,
		// deleted or updated
		Collection storedContacts = store.getBindings(aor).getContacts();
		Collection newContacts = binding.getContacts();
		Iterator ncit = newContacts.iterator();

		// run through all the contacts and expiry figures of the latest
		// registration and update, delete or add them to the actual binding
		while (ncit.hasNext()) {
			Contact nc = (Contact) ncit.next();
			Iterator scit = storedContacts.iterator();
			boolean found = false;
			while (scit.hasNext()) {
				Contact sc = (Contact) scit.next();
				if (nc.getContact().compareTo(sc.getContact()) == 0) {
					// found the contact in the binding
					found = true;
					if (nc.getExpire() == 0) {
						scit.remove();
					} else
						sc.updateExpires(nc.getExpire());
				}
			}
			if (!found) {
				if (nc.getExpire() != 0)
					store.addContact(aor, nc);
			}
		}
		// here, the list of contacts is empty and we need to clean up the list
		// of registrations
		if (storedContacts.isEmpty())
			store.removeBinding(aor);
	}

	/**
	 * Returns all Bindings in a Collection.
	 * 
	 * @return returns a Collection of all stored bindings in the store
	 */
	public Collection getAllBindings() {
		return store.getAllBindings();
	}

	/**
	 * Allows for resource clean up. Here, the timer is cancelled.
	 */
	public void cleanUp() {
		timer.cancel();
	}

	/**
	 * Looksup the binding information for a specific AOR. Implements the
	 * interface QueryLocationService.
	 * 
	 * @param aor the Address Of Record (aor) to lookup
	 * @return binding the Registration object to be associated with this AOR
	 */
	public Registration lookupBinding(String aor) {
		return getBindings(aor);
	}

}
