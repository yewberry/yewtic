//
// C++ Interface: foperationlist
//
// Description: 
//
//
// Author: Peter <marcusk@i.ua>, (C) 2009
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef FOPERATIONLIST_H
#define FOPERATIONLIST_H

#include <QTreeWidget>

static int SYS_TYPE = 1;
static int INC_TYPE = SYS_TYPE+1;
static int EXC_TYPE = SYS_TYPE+2;

/**
	@author Peter <marcusk@i.ua>
*/
class FOperationList : public QTreeWidget
{
Q_OBJECT
public:
    FOperationList(QWidget* parent);

    ~FOperationList();

protected:
  void drawRow(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const;
  void drawBranches ( QPainter * painter, const QRect & rect, const QModelIndex & index ) const;
};

#endif
