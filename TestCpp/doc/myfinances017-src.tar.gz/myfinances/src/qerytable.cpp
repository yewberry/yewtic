//
// C++ Implementation: qerytable
//
// Description: 
//
//
// Author: Peter <marcusk@i.ua>, (C) 2009
//
// Copyright: See COPYING file that comes with this distribution
//
//
#include "qerytable.h"
#include <QtGui>

const char* date_f = "dd.MM.yyyy";

class SimpleDelegate : public QItemDelegate
{
	public:
		SimpleDelegate(QObject*pobj=0) : QItemDelegate(pobj)
		{
		}
     
		QWidget* createEditor( QWidget * parent, const QStyleOptionViewItem & option, const QModelIndex & index ) const
		{
			int i = index.column();
			int row = index.row();
	     
			if(!i)
				return NULL;
			
			if((i>1) && (row == 2))
			        return NULL;
			
			QString s1 = index.model()->data(index.sibling(index.row(),2), Qt::EditRole).toString();
			
			if(((i == 2) || (i == 4)) && (row == 0))//date line
			{
				if(i ==  4)
					if(s1.isEmpty())
						return NULL;
				QDateTimeEdit *ed = new QDateTimeEdit(parent);
				ed->setDateTime(QDateTime::currentDateTime());
				ed->setCalendarPopup(true);
				ed->setDisplayFormat(date_f);
			     
				return ed;
			}
			
			if(((i == 2) || (i == 4)) && (row == 1))//date line
			{
				if(i ==  4)
					if(s1.isEmpty())
						return NULL;
				QLineEdit *ed = new QLineEdit(parent);
				QDoubleValidator *valid = new QDoubleValidator(0.00,9999999999999.99,2,0);
				ed->setValidator(valid);
				
				return ed;
			}
			
			if(((i == 1) || (i == 3)) && ((row == 0) || (row == 1)))
			{
				QString s="";
				if(i == 3)
				   s = index.model()->data(index.sibling(index.row(),1), Qt::EditRole).toString();
				
				if((s == ">") || (s == ">="))
				{
					QComboBox *c_box_condition = new QComboBox(parent);
					c_box_condition->setEditable(false);
					QStringList list_types;
					list_types << "" << "<" << "<=";
					c_box_condition->addItems(list_types);
		     
					return c_box_condition;
				}
				
				if((s == "<") || (s == "<="))
				{
					QComboBox *c_box_condition = new QComboBox(parent);
					c_box_condition->setEditable(false);
					QStringList list_types;
					list_types << "" << ">" << ">=";
					c_box_condition->addItems(list_types);
		     
					return c_box_condition;
				}
				
				if(s == "=")
					return NULL;
				
				if(s == "")
				{
					QComboBox *c_box_condition = new QComboBox(parent);
					c_box_condition->setEditable(false);
					QStringList list_types;
					list_types << "=" << ">"
							<< ">=" << "<" << "<=";
					c_box_condition->addItems(list_types);
		     
					return c_box_condition;
				}
			}
			
	     		return QItemDelegate::createEditor(parent, option, index );
		}
     
		void setEditorData(QWidget *editor, const QModelIndex &index) const
		{
			int icolumn = index.column();
			int irow = index.row();
			
			
			if(((icolumn == 2) || (icolumn == 4)) && (irow == 0))//date line
			{
				QDateTimeEdit *ed = static_cast<QDateTimeEdit*>(editor);
				QString s  = index.model()->data(index, Qt::EditRole).toString();
				QDateTime value = QDateTime::fromString(s,date_f);
				ed->setDateTime(value);
				return;
			}
			
			if(((icolumn == 1) || (icolumn == 3)) && ((irow == 0) || (irow == 1)))
			{
				QString value = index.model()->data(index, Qt::EditRole).toString();
				QComboBox *c_box_condition = static_cast<QComboBox*>(editor);
				c_box_condition->setCurrentIndex(c_box_condition->findText(value));
				return;
			}
	     
			QItemDelegate::setEditorData(editor, index);
			
		}
     
		void setModelData(QWidget *editor, QAbstractItemModel *model, const QModelIndex &index) const
		{
			int icolumn = index.column();
			int irow = index.row();
			
			
			if(((icolumn == 2) || (icolumn == 4)) && (irow == 0))//date line
			{
				QDateTimeEdit *ed = static_cast<QDateTimeEdit*>(editor);
				QString value = ed->dateTime().toString(date_f);
				model->setData(index, value, Qt::EditRole);
				return;
			}
			
			if(((icolumn == 1) || (icolumn == 3)) && ((irow == 0) || (irow == 1)))
			{
				QComboBox *c_box_condition = static_cast<QComboBox*>(editor);
				QString value = c_box_condition->currentText();
				model->setData(index, value, Qt::EditRole);
				return;
			}
	     
	     		QItemDelegate::setModelData(editor, model, index);
		}
     
		void updateEditorGeometry(QWidget *editor, const QStyleOptionViewItem &option, const QModelIndex & /*index*/ ) const
		{
			editor->setGeometry(option.rect);
		}
		
		bool editorEvent ( QEvent * event, QAbstractItemModel * model, const QStyleOptionViewItem & option, const QModelIndex & index )
		{
			if(event->type() == QEvent::KeyPress)
			{
				QKeyEvent* ev = static_cast<QKeyEvent*>(event);
				
				if(ev->key() == Qt::Key_Delete)
				{
					int icolumn = index.column();
					int irow = index.row();
					
					if(((icolumn >= 2) && ((irow == 0) || (irow == 1)))
						|| ((irow == 2) && (icolumn == 1)))//date line
					{
					   model->setData(index, "", Qt::EditRole);
					   return true;
					}
				}
			}
			return QItemDelegate::editorEvent(event, model, option, index);
		}
};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

QeryTable::QeryTable(QWidget *parent)
	: QTreeView(parent)
{
	setEditTriggers(QAbstractItemView::DoubleClicked | QAbstractItemView::EditKeyPressed);
	setItemDelegate(new SimpleDelegate(this));
}


QeryTable::~QeryTable()
{
}


void QeryTable::drawRow(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const
{
	QStyleOptionViewItemV3 opt = option;
	
	QColor color = static_cast<QRgb>(QApplication::style()->styleHint(QStyle::SH_Table_GridLineColor, &opt));
	painter->save();
	painter->setPen(QPen(color));
	painter->drawLine(opt.rect.x(), opt.rect.bottom(), opt.rect.right(), opt.rect.bottom());
	
	int cs=0;//draw vertical lines
	for(int i = 0; i<(header()->count()); i++)
	{
		cs += columnWidth(i);
		painter->drawLine(opt.rect.x()+cs,opt.rect.top(), opt.rect.x()+cs, opt.rect.bottom());
	}
		
	painter->restore();
	QTreeView::drawRow(painter, opt, index);
}


/*!
    \fn QeryTable::setSourceModel(QAbstractItemModel *model)
 */
void QeryTable::setSourceModel(QAbstractItemModel *model)
{
	setModel(model);
}
