//
// C++ Implementation: dockwidg
//
// Description: 
//
//
// Author: peter komar <peter@linux-nlyt>, (C) 2008
//
// Copyright: See COPYING file that comes with this distribution
//
//
#include "dockwidg.h"
#include "fdatabase.h"

#include <QtGui>

DockWidg::DockWidg(QWidget *parent)
 : QDialog(parent)
{
        listCred = new QTreeWidget(this);
        NewBtn = new QPushButton(this);
        infBtn  = new QPushButton(this);
        RemBtn = new QPushButton(this);

        QVBoxLayout *pvbxLayout = new QVBoxLayout;
        QHBoxLayout *phbxLayout = new QHBoxLayout;
        pvbxLayout->addWidget(listCred);
        phbxLayout->addWidget(NewBtn);
        phbxLayout->addWidget(infBtn);
        phbxLayout->addWidget(RemBtn);
        pvbxLayout->addLayout(phbxLayout);
        setLayout(pvbxLayout);



        reload_ui();
        QHeaderView *h = listCred->header();
        //h->setResizeMode(QHeaderView::ResizeToContents);
	h->setMovable(FALSE);

        
	listCred->setDragEnabled(FALSE);
	listCred->setSelectionMode(QAbstractItemView::ExtendedSelection);
	
	load_data();
	
}


DockWidg::~DockWidg()
{
}


void DockWidg::reload_ui()
{
    NewBtn->setText(tr("New mortgagor..."));
    infBtn->setText(tr("About  mortgagor..."));
    RemBtn->setText(tr("Paying off..."));
    QStringList labels;
    labels << tr("Name mortgagors") << tr("Count") << tr("Date");
    listCred->setHeaderLabels(labels);
}

/*!
    \fn DockWidg::load_data()
 */
void DockWidg::load_data()
{
	listCred->clear();
	
	QList<Db_dat> list = load_data_from_creditors();
	
	QTreeWidgetItem *item;
	
	for (int i = 0; i < list.size(); ++i) {
		
		Db_dat dat = list.at(i);
		
		item = new QTreeWidgetItem();
		
		item->setText(2,dat.date);
		
		QString s;
		s = s.number(dat.count_d,'F',2);
		item->setText(1,s+" "+dat.currency);
		
		item->setText(0,dat.Name);
		
		listCred->addTopLevelItem(item);
	}
}
