//
// C++ Implementation: newopdlgimpl
//
// Description: 
//
//
// Author: peter komar <peter@linux-nlyt>, (C) 2008
//
// Copyright: See COPYING file that comes with this distribution
//
//
#include "newopdlgimpl.h"
#include "fdatabase.h"

#include <QMessageBox>
#include <QCalendarWidget>

NewOpDlgImpl::NewOpDlgImpl(QWidget *parent)
	: QDialog(parent) 
{
	setupUi(this);

	dateTimeEdit->setDateTime(QDateTime::currentDateTime());
	
	dateTimeEdit->setDisplayFormat(get_display_format());

	connect(okBtn, SIGNAL(clicked()), this, SLOT(slot_bAdd()));
	connect(cancelBtn, SIGNAL(clicked()), this, SLOT(slot_exit()));
	
	QString name_currency;
	double d;
	get_data_from_bank(d, name_currency);
	
	lineEdit->setSuffix(name_currency);

	b_Ex=false;
}


NewOpDlgImpl::~NewOpDlgImpl()
{
}




/*!
    \fn NewOpDlgImpl::slot_bAdd(int )
 */
void NewOpDlgImpl::slot_bAdd()
{
	if(radioButton->isChecked())
		bAdd=1;
	else
		bAdd=0;
	
	double d = lineEdit->value();
    
	if(!d)
	{
            QMessageBox::information(this,tr("info"),tr("Please enter count cash"));
            return;
	}
    	
	accept();
}


/*!
    \fn NewOpDlgImpl::get_bAdd()
 */
bool NewOpDlgImpl::get_bAdd()
{
    if(bAdd>=1)
	    return true;
    else
	return false;
}


/*!
    \fn NewOpDlgImpl::slot_exit()
 */
void NewOpDlgImpl::slot_exit()
{
	b_Ex=true;
	
	reject();
}
