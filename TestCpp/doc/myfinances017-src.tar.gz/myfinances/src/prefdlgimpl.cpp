#include "prefdlgimpl.h"
#include "fdatabase.h"

#include <QtGui>
#include <QSettings>
#include <QApplication>

/////////////////////parameters dialog/////////////////////////////////////////
parameter_dlg::parameter_dlg(QWidget *parent)
        :QDialog(parent)
{
        setWindowTitle(tr("New currency"));
        QPushButton *okBtn = new QPushButton(tr("OK"));
        QPushButton *cancelBtn = new QPushButton(tr("Cancel"));
        ename = new QLineEdit(this);
        erate = new QLineEdit(this);
        QLabel *lab_name = new QLabel(tr("Name currency:"),this);
        QLabel *lab_rate = new QLabel(tr("Rate:"),this);
        QDoubleValidator *dv = new QDoubleValidator(0.00,99999.999999,6,this);
        erate->setValidator(dv);

        connect(okBtn,SIGNAL(clicked()),this,SLOT(accept()));
        connect(cancelBtn,SIGNAL(clicked()),this,SLOT(reject()));

        QGridLayout *gLayout = new QGridLayout(this) ;
        gLayout->addWidget(lab_name,0,0 );
        gLayout->addWidget(ename,0,1);
        gLayout->addWidget(okBtn,0,2);
        gLayout->addWidget(lab_rate,1,0,Qt::AlignRight);
        gLayout->addWidget(erate,1,1);
        gLayout->addWidget(cancelBtn,1,2);
        setLayout(gLayout);

        setMinimumSize(QSize(425, 115));
        setMaximumSize(QSize(425, 115));
}

void parameter_dlg::set_data(const QString& name, const QString& rate)
{
    ename->setText(name);
    ename->setReadOnly(TRUE);
    erate->setText(rate);
    setWindowTitle(tr("Change currency rate"));
}

bool parameter_dlg::get_data(QString& name, QString& rate)
{
    bool bret= true;

    name = ename->text();
    rate = erate->text();
    name.simplified();
    rate.simplified();

    if(name.isEmpty() || rate.isEmpty()) {
        bret = false;
    }

    return bret;
}


////////////////////////////////////////////////////////////////////

const char* PrefDlgImpl::company = "UaDevLab";
const char* PrefDlgImpl::key = "myfinances";

PrefDlgImpl::PrefDlgImpl(bool bfirs_show, QWidget *parent)
	: QDialog(parent), bfirst(bfirs_show)
{
    setupUi(this);

    currencylist->setAllColumnsShowFocus(true);
    currencylist->setAlternatingRowColors(true);
    QStringList labels;
    labels << tr("Name currency") << tr("Rate");
    currencylist->setHeaderLabels(labels);
    
    QList<data_curs>listc = get_curs_curency();
   
    QTreeWidgetItem *pItem = new QTreeWidgetItem;
        
    for(int i=0;i<listc.size();i++)
    {
	    data_curs d = (data_curs)listc.at(i);
	    
	    if(d.b_main)
	    {
		pItem->setText(0,d.name_curency);
	    }
	    else
	    {
               QTreeWidgetItem *item = new QTreeWidgetItem;
	       item->setText(0,d.name_curency);
	       item->setText(1,QString::number(d.curs,'F',6));
	       pItem->addChild(item);
	    }
	    currencyCombo->addItem(d.name_curency);
    }
    double* d = new double;
    QString s;
    
    get_data_from_bank(*d, s);
    delete d;
    
    currencyCombo->setCurrentIndex(currencyCombo->findText(s));
    
    currencylist->insertTopLevelItem(0,pItem);
    currencylist->expandItem(pItem);
        
    listc.clear();
    
    QDir dir(QApplication::applicationDirPath()+"/lang");
    dir.setNameFilters(QStringList () << "*.qm");
    QFileInfoList list = dir.entryInfoList();
    QStringList list1;
    list1<< "English";
    for (int i = 0; i < list.size(); ++i) {
        QFileInfo fileInfo = list.at(i);
		if(fileInfo.baseName().left(3) != "qt_")
            list1 += fileInfo.baseName();
     }
    comboBox->addItems(list1);

    QSettings settings(PrefDlgImpl::company, PrefDlgImpl::key);
    old_lang = settings.value("lang",QString("English")).toString();
    comboBox->setCurrentIndex(comboBox->findText(old_lang));
    
    connect(okBtn, SIGNAL(clicked()), this, SLOT(slot_ok()));
    connect(addBtn, SIGNAL(clicked()), this, SLOT(slot_add()));
    connect(remBtn, SIGNAL(clicked()), this, SLOT(slot_rem()));
    connect(cangeBtn, SIGNAL(clicked()), this, SLOT(slot_ch()));
    connect(setmBtn, SIGNAL(clicked()), this, SLOT(slot_set_main()));
    
    if(bfirs_show){
	    tabWidget->setCurrentIndex(1);
		label_3->setVisible(FALSE);
		eold_pass->setVisible(FALSE);
		label_4->setText(tr("Password"));
	}
}

void PrefDlgImpl::slot_ok()
{
    QTreeWidgetItem *pItem = currencylist->topLevelItem(0);
    
    if(!pItem)
    {
	    QMessageBox::critical(this,tr("Fatal error"),tr("Database currency is corrupted."));
	    reject();
    }

    QList<data_curs> list;
    
    data_curs data;
    data.b_main = true;
    data.name_curency = pItem->text(0);
    data.curs = 1;
    list.append(data);

    for(int i=0; i<pItem->childCount(); i++)
    {
        QTreeWidgetItem* item = pItem->child(i);
        data.name_curency = item->text(0);
        data.curs = item->text(1).toDouble();
        data.b_main = false;
	
        list.append(data);
    }

    save_curs(list);
    list.clear();

    QString name = comboBox->currentText();

    if(name != old_lang)
    {
        QSettings settings(PrefDlgImpl::company, PrefDlgImpl::key);
        settings.setValue("lang", name);
    }
    name = currencyCombo->currentText();
    convert_currency_account(name,bfirst);
    
    QString s1 = eold_pass->text();
    QString s2 = enew_pass1->text();
    QString s3 = enew_pass2->text();
    
    if(!(s1.isEmpty()) || !(s2.isEmpty()) || !(s3.isEmpty()))
    {
	    if(s1 != get_password())
	    {
		QMessageBox::critical(this, tr("Error password"), tr("Old password is incorrect."));
		return;
	    }
	    
	    if(s2 != s3)
	    {
		    QMessageBox::critical(this, tr("Error password"), tr("Passwords is not equable.."));
		return; 
	    }
	    
	    set_password(s2);
    }
    
    accept();
}

void PrefDlgImpl::slot_add()
{
    parameter_dlg *dlg = new parameter_dlg(this);

    dlg->exec();
    QString s1,s2;
    
    QTreeWidgetItem *pI =currencylist->topLevelItem(0);
    
    if(!pI)
    {
	    QMessageBox::critical(this,tr("Fatal error"),tr("Database currency is corrupted."));
	    return;
    }

    if(dlg->get_data(s1,s2))
    {
        int ifind = currencyCombo->findText(s1);

        if(ifind<0)
        {
            QTreeWidgetItem *item = new QTreeWidgetItem(pI);
            item->setText(0,s1);
            item->setText(1,s2);
            pI->addChild(item);
            currencyCombo->addItem(s1);
        }
        else
           QMessageBox::information(this,tr("Currency"),
                                     tr("Currency <b>%1</b> is really exist").arg(s1));
    }

    delete dlg;
}

void PrefDlgImpl::slot_rem()
{
    QTreeWidgetItem *item = currencylist->currentItem();
    
    if(!item->parent())
	    return;

    if(!item)
        return;

    int i = QMessageBox::question(this, tr("Delete cash"),
                                tr("Confirm delete currency <b>%1</b>?").arg(item->text(0)),
                                QMessageBox::Yes | QMessageBox::No);
    if(i == QMessageBox::Yes)
    {
        int ifind = currencyCombo->findText(item->text(0));

        if(ifind>=0)
            currencyCombo->removeItem(ifind);

        delete item;
    }
}

void PrefDlgImpl::slot_ch()
{
	QTreeWidgetItem *item = currencylist->currentItem();

	if(!item)
		return;
	
	QTreeWidgetItem* pitem = item->parent();
	
	if(!pitem)
		return;

			
        parameter_dlg *dlg = new parameter_dlg(this);
	
	QString s1,s2 = item->text(1);
        dlg->set_data( item->text(0),s2);

	dlg->exec();
	
        if(dlg->get_data(s1,s2))
	{
		item->setText(0,s1);
		item->setText(1,s2);
	}


	delete dlg;
}



/*!
    \fn PrefDlgImpl::slot_set_main()
 */
void PrefDlgImpl::slot_set_main()
{
	QTreeWidgetItem *pitem = currencylist->currentItem();
	if(!pitem)
		return;
	
		
	QTreeWidgetItem *mItem = pitem->parent();
	
	if(!mItem)
		return;//this is main currency
	
	double rdata = pitem->text(1).toDouble();
	pitem->setText(1,"");
	
	currencylist->takeTopLevelItem(0);
	
	int cIndex = mItem->indexOfChild(pitem);
	mItem->takeChild(cIndex);
	
	currencylist->insertTopLevelItem(0,pitem);
	
	pitem->addChild(mItem);
	double d = 1/rdata;
	mItem->setText(1,QString::number(d,'F',6));
	
	int i = 0;
	
	while(mItem->childCount()>0)
	{
		QTreeWidgetItem* chItem = mItem->takeChild(i);
		
		double dt = chItem->text(1).toDouble();
		dt /= rdata;
		chItem->setText(1,QString::number(dt,'F',6));
				
		pitem->addChild(chItem);
	}
	
	currencylist->expandItem(pitem);
}
