<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="de_DE">
<context>
    <name>AddCredDlg</name>
    <message>
        <location filename="../ui/addcredit.ui" line="14"/>
        <source>Add credit</source>
        <translation>Neuer Kredit</translation>
    </message>
    <message>
        <location filename="../ui/addcredit.ui" line="203"/>
        <source>Description</source>
        <translation>Beschreibung</translation>
    </message>
    <message>
        <location filename="../ui/addcredit.ui" line="143"/>
        <source>Ok</source>
        <translation type="obsolete">ОK</translation>
    </message>
    <message>
        <location filename="../ui/addcredit.ui" line="151"/>
        <source>Cancel</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location filename="../ui/addcredit.ui" line="29"/>
        <source>Name mortgagor</source>
        <translation>Name der Schuldner</translation>
    </message>
    <message>
        <location filename="../ui/addcredit.ui" line="39"/>
        <source>Count</source>
        <translation>Quantum</translation>
    </message>
    <message>
        <location filename="../ui/addcredit.ui" line="53"/>
        <source>Data</source>
        <translation>Datum</translation>
    </message>
    <message>
        <location filename="../ui/addcredit.ui" line="23"/>
        <source>Mortgagor data</source>
        <translation>Daten Schuldner</translation>
    </message>
    <message>
        <location filename="../ui/addcredit.ui" line="67"/>
        <source>Percentage</source>
        <translation>Prozent</translation>
    </message>
    <message>
        <location filename="../ui/addcredit.ui" line="77"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../ui/addcredit.ui" line="87"/>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <location filename="../ui/addcredit.ui" line="110"/>
        <source>Month</source>
        <translation>Monatiger</translation>
    </message>
    <message>
        <location filename="../ui/addcredit.ui" line="115"/>
        <source>Year</source>
        <translation>Jähriger</translation>
    </message>
    <message>
        <location filename="../ui/addcredit.ui" line="171"/>
        <source>More</source>
        <translation>Groß</translation>
    </message>
    <message>
        <location filename="../ui/addcredit.ui" line="144"/>
        <source>OK</source>
        <translation>ОК</translation>
    </message>
</context>
<context>
    <name>AddCredDlgImpl</name>
    <message>
        <location filename="../addcreddlgimpl.cpp" line="77"/>
        <source>info</source>
        <translation>Information</translation>
    </message>
    <message>
        <location filename="../addcreddlgimpl.cpp" line="70"/>
        <source>Please enter count mortgagor</source>
        <translation>Einführe Betrag des Anlehens</translation>
    </message>
    <message>
        <location filename="../addcreddlgimpl.cpp" line="77"/>
        <source>Please enter name mortgagor</source>
        <translation>Einführe Namen der Schuldner</translation>
    </message>
    <message>
        <location filename="../addcreddlgimpl.cpp" line="111"/>
        <source>Info mortgagor</source>
        <translation>Information über Schuldner</translation>
    </message>
    <message>
        <location filename="../addcreddlgimpl.cpp" line="143"/>
        <source>Year</source>
        <translation>Jähriger</translation>
    </message>
    <message>
        <location filename="../addcreddlgimpl.cpp" line="109"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location filename="../addcreddlgimpl.cpp" line="152"/>
        <source>Credit</source>
        <translation>Kredit</translation>
    </message>
    <message>
        <location filename="../addcreddlgimpl.cpp" line="152"/>
        <source>debtor</source>
        <translation>Schuldner</translation>
    </message>
    <message>
        <location filename="../addcreddlgimpl.cpp" line="154"/>
        <source>Info</source>
        <translation>Information</translation>
    </message>
    <message>
        <location filename="../addcreddlgimpl.cpp" line="156"/>
        <source>Percent stake</source>
        <translation>Prozentualer Satz</translation>
    </message>
    <message>
        <location filename="../addcreddlgimpl.cpp" line="157"/>
        <source>Percent</source>
        <translation>Prozent</translation>
    </message>
    <message>
        <location filename="../addcreddlgimpl.cpp" line="158"/>
        <source>Count borrowing</source>
        <translation>Betrag den Anlehen</translation>
    </message>
    <message>
        <location filename="../addcreddlgimpl.cpp" line="161"/>
        <source>Note</source>
        <translation>Datenbeschreibung</translation>
    </message>
</context>
<context>
    <name>DockWidg</name>
    <message>
        <location filename="../dockwidg.cpp" line="57"/>
        <source>New mortgagor...</source>
        <translation>Neuer Schuldner...</translation>
    </message>
    <message>
        <location filename="../dockwidg.cpp" line="58"/>
        <source>About  mortgagor...</source>
        <translation>Über Schuldner...</translation>
    </message>
    <message>
        <location filename="../dockwidg.cpp" line="59"/>
        <source>Paying off...</source>
        <translation>Schuldtilgung...</translation>
    </message>
    <message>
        <location filename="../dockwidg.cpp" line="61"/>
        <source>Name mortgagors</source>
        <translation>Name der Schuldner</translation>
    </message>
    <message>
        <location filename="../dockwidg.cpp" line="61"/>
        <source>Count</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <location filename="../dockwidg.cpp" line="61"/>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
</context>
<context>
    <name>FilterDlg</name>
    <message>
        <location filename="../ui/filterdialog.ui" line="13"/>
        <source>Filter dialog</source>
        <translation>Filter Dialog</translation>
    </message>
    <message>
        <location filename="../ui/filterdialog.ui" line="21"/>
        <source>Filtred type operations:</source>
        <translation>Baumuster der Operationen zu filtern:</translation>
    </message>
    <message>
        <location filename="../ui/filterdialog.ui" line="29"/>
        <source>All</source>
        <translation>Alles</translation>
    </message>
    <message>
        <location filename="../ui/filterdialog.ui" line="38"/>
        <source>Income</source>
        <translation>Profit</translation>
    </message>
    <message>
        <location filename="../ui/filterdialog.ui" line="47"/>
        <source>Expense</source>
        <translation>Ausgabe</translation>
    </message>
    <message>
        <location filename="../ui/filterdialog.ui" line="61"/>
        <source>Filter</source>
        <translation>Filter</translation>
    </message>
    <message>
        <location filename="../ui/filterdialog.ui" line="74"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
</context>
<context>
    <name>FilterDlgImpl</name>
    <message>
        <location filename="../filterdlgimpl.cpp" line="36"/>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <location filename="../filterdlgimpl.cpp" line="38"/>
        <source>Count</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <location filename="../filterdlgimpl.cpp" line="40"/>
        <source>Description</source>
        <translation>Beschreibung</translation>
    </message>
</context>
<context>
    <name>Finances</name>
    <message>
        <location filename="../finances.cpp" line="759"/>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="759"/>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="760"/>
        <source>Count</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="760"/>
        <source>Description</source>
        <translation>Beschreibung</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="207"/>
        <source>Add operation</source>
        <translation>Neue operation</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="259"/>
        <source>Add new finance operation</source>
        <translation>Addieren neuen funanzielle operation</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="208"/>
        <source>View</source>
        <translation>Beschau</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="269"/>
        <source>Show selected year transactions</source>
        <translation>Operationen auf gewähltes Jahr zu aufweisen</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="209"/>
        <source>Print report</source>
        <translation>Druck</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="278"/>
        <source>Print report transaction</source>
        <translation>Bericht zu drucken</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="210"/>
        <source>Preferences</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="287"/>
        <source>Configure Personal finances</source>
        <translation>Einstellung das personale Finanzen</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="211"/>
        <source>Help</source>
        <translation>Hilfe</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="296"/>
        <source>Show about dialog</source>
        <translation>Zeigen Dialog über programme</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="215"/>
        <source>Reset filter</source>
        <translation>Filterlöschung</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="366"/>
        <source>Debtor</source>
        <translation>Schuldner</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="381"/>
        <source>Paying off credit</source>
        <translation>Schuldtilgung</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="511"/>
        <source>Filter</source>
        <translation>Filter</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="511"/>
        <source>Select Year transaction</source>
        <translation>Aufweisen operationen des Jahre</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="366"/>
        <source>Currency</source>
        <translation>Valuta</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="214"/>
        <source>Custom filter</source>
        <translation>Wählbar filter</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="216"/>
        <source>About myFinaces</source>
        <translation>Über myFinances</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="217"/>
        <source>About Qt</source>
        <translation>Über Qt</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="565"/>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="765"/>
        <source>Income</source>
        <translation>Profit</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="770"/>
        <source>Expense</source>
        <translation>Ausgabe</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="670"/>
        <source>About myFinances</source>
        <translation>Über myFinances</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="673"/>
        <source>Copyright (C) 2008 Peter Komar &lt;a href=&quot;http://sksoft-gr.narod.ru&quot;&gt;http://sksoft-gr.narod.ru&lt;/a&gt;</source>
        <translation>Copyright (C) 2008 Peter Komar &lt;a href=&quot;http://sksoft-gr.narod.ru&quot;&gt;http://sksoft-gr.narod.ru&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="203"/>
        <source>Cash panel</source>
        <translation>Panel des Bestands</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="204"/>
        <source>Mortgagors panel</source>
        <translation>Panel des Schuldner</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="718"/>
        <source>Help browser</source>
        <translation>Auskunft</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="499"/>
        <source>New</source>
        <translation>Neu</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="499"/>
        <source>finance year</source>
        <translation>finanzielles Jahr</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="672"/>
        <source>&lt;b&gt;myFinances 0.15 PE &lt;/b&gt; - home finance operation manager.&lt;br&gt;</source>
        <translation>&lt;b&gt;myFinances 0.15 PE &lt;/b&gt; - Manager der finanziellen Häuseroperationen.&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="571"/>
        <source> All years</source>
        <translation>Alles Jahres</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="573"/>
        <source>Show operations with custom filter:</source>
        <translation>Operationen filter:</translation>
    </message>
</context>
<context>
    <name>HelpBrowser</name>
    <message>
        <location filename="../helpbrowser.cpp" line="49"/>
        <source>Home</source>
        <translation>Heim</translation>
    </message>
</context>
<context>
    <name>MDialog</name>
    <message>
        <location filename="../ui/parameters.ui" line="25"/>
        <source>Dialog</source>
        <translation>Dialog</translation>
    </message>
    <message>
        <location filename="../ui/parameters.ui" line="86"/>
        <source>TextLabel</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui/parameters.ui" line="79"/>
        <source>OK</source>
        <translation>ОК</translation>
    </message>
    <message>
        <location filename="../ui/parameters.ui" line="96"/>
        <source>Cancel</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location filename="../ui/parameters.ui" line="103"/>
        <source>New account</source>
        <translation>Neuer Abzählung</translation>
    </message>
</context>
<context>
    <name>MDialogImpl</name>
    <message>
        <location filename="../mdialogimpl.cpp" line="31"/>
        <source>Acount</source>
        <translation>Rechnung</translation>
    </message>
    <message>
        <location filename="../mdialogimpl.cpp" line="32"/>
        <source>Password</source>
        <translation>Parole</translation>
    </message>
    <message>
        <location filename="../mdialogimpl.cpp" line="39"/>
        <source>Login</source>
        <translation>Eingang</translation>
    </message>
    <message>
        <location filename="../mdialogimpl.cpp" line="40"/>
        <source>Exit</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location filename="../mdialogimpl.cpp" line="74"/>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <location filename="../mdialogimpl.cpp" line="74"/>
        <source>Account is exist.</source>
        <translation>Abzählung ist schon sein.</translation>
    </message>
    <message>
        <location filename="../mdialogimpl.cpp" line="36"/>
        <source>Authorization</source>
        <translation>Autorisiert</translation>
    </message>
    <message>
        <location filename="../mdialogimpl.cpp" line="66"/>
        <source>Please enter name account.</source>
        <translation>Bitte einführe Benennung der Abzählung.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../ui/mainfrm.ui" line="14"/>
        <source>Personal finances</source>
        <translation>Personalerfinanzielle</translation>
    </message>
</context>
<context>
    <name>NewOpDlgImpl</name>
    <message>
        <location filename="../newopdlgimpl.cpp" line="61"/>
        <source>info</source>
        <translation>Information</translation>
    </message>
    <message>
        <location filename="../newopdlgimpl.cpp" line="61"/>
        <source>Please enter count cash</source>
        <translation>Bitte einführe Betrag des Geld</translation>
    </message>
</context>
<context>
    <name>NewopDlg</name>
    <message>
        <location filename="../ui/newop.ui" line="14"/>
        <source>New operation</source>
        <translation>Neue operation</translation>
    </message>
    <message>
        <location filename="../ui/newop.ui" line="23"/>
        <source>Type operation</source>
        <translation>Typ operation</translation>
    </message>
    <message>
        <location filename="../ui/newop.ui" line="51"/>
        <source>Date operation</source>
        <translation>Daten operation</translation>
    </message>
    <message>
        <location filename="../ui/newop.ui" line="127"/>
        <source>Cancel</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location filename="../ui/newop.ui" line="95"/>
        <source>Count</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <location filename="../ui/newop.ui" line="83"/>
        <source>OK</source>
        <translation>ОК</translation>
    </message>
    <message>
        <location filename="../ui/newop.ui" line="134"/>
        <source>Description</source>
        <translation>Beschreibung</translation>
    </message>
    <message>
        <location filename="../ui/newop.ui" line="29"/>
        <source>Income</source>
        <translation>Profit</translation>
    </message>
    <message>
        <location filename="../ui/newop.ui" line="39"/>
        <source>Expense</source>
        <translation>Ausgabe</translation>
    </message>
</context>
<context>
    <name>PanelCash</name>
    <message>
        <location filename="../panelcash.cpp" line="49"/>
        <source>Currency</source>
        <translation>Valuta</translation>
    </message>
    <message>
        <location filename="../panelcash.cpp" line="49"/>
        <source>Rate</source>
        <translation>Kurs</translation>
    </message>
    <message>
        <location filename="../panelcash.cpp" line="70"/>
        <source>Income state on:</source>
        <translation>Profit Befund an:</translation>
    </message>
    <message>
        <location filename="../panelcash.cpp" line="72"/>
        <source>Year</source>
        <translation>Jähr</translation>
    </message>
    <message>
        <location filename="../panelcash.cpp" line="72"/>
        <source>Expenses state on:</source>
        <translation>Ausgabe Befund an:</translation>
    </message>
</context>
<context>
    <name>PrefDlg</name>
    <message>
        <location filename="../ui/prefdlg.ui" line="14"/>
        <source>Preferences</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <location filename="../ui/prefdlg.ui" line="36"/>
        <source>Currency</source>
        <translation>Valuta</translation>
    </message>
    <message>
        <location filename="../ui/prefdlg.ui" line="52"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../ui/prefdlg.ui" line="60"/>
        <source>add currency</source>
        <translation>Neue Valuta</translation>
    </message>
    <message>
        <location filename="../ui/prefdlg.ui" line="63"/>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <location filename="../ui/prefdlg.ui" line="70"/>
        <source>remove  selected currency</source>
        <translation>Entfernen gewählte Valute</translation>
    </message>
    <message>
        <location filename="../ui/prefdlg.ui" line="73"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../ui/prefdlg.ui" line="80"/>
        <source>Change curs selected currency</source>
        <translation>Ändern Valuta Kurs sich</translation>
    </message>
    <message>
        <location filename="../ui/prefdlg.ui" line="83"/>
        <source>.</source>
        <translation>.</translation>
    </message>
    <message>
        <location filename="../ui/prefdlg.ui" line="218"/>
        <source>Language</source>
        <translation>Sprache</translation>
    </message>
    <message>
        <location filename="../ui/prefdlg.ui" line="228"/>
        <source>OK</source>
        <translation>ОК</translation>
    </message>
    <message>
        <location filename="../ui/prefdlg.ui" line="235"/>
        <source>Cancel</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location filename="../ui/prefdlg.ui" line="26"/>
        <source>Change currency account. This not change creditors currency.</source>
        <translation>Abwandelt Währung der Abzählung. Dieser nicht tauscht Währung Schuldner.</translation>
    </message>
    <message>
        <location filename="../ui/prefdlg.ui" line="103"/>
        <source>Set selected currency main</source>
        <translation>Aufstellen Leitwährung</translation>
    </message>
    <message>
        <location filename="../ui/prefdlg.ui" line="118"/>
        <source>Account settings</source>
        <translation>Abzählung Parameter</translation>
    </message>
    <message>
        <location filename="../ui/prefdlg.ui" line="124"/>
        <source>Chage currency account</source>
        <translation>Abwandelt Währung der Abzählung</translation>
    </message>
    <message>
        <location filename="../ui/prefdlg.ui" line="134"/>
        <source>Change password</source>
        <translation>Parole Abwandelt</translation>
    </message>
    <message>
        <location filename="../ui/prefdlg.ui" line="142"/>
        <source>Old password</source>
        <translation>Alte Parole</translation>
    </message>
    <message>
        <location filename="../ui/prefdlg.ui" line="175"/>
        <source>New password</source>
        <translation>Neue Parole</translation>
    </message>
    <message>
        <location filename="../ui/prefdlg.ui" line="193"/>
        <source>Confirm password</source>
        <translation>Parole bestätigen</translation>
    </message>
    <message>
        <location filename="../ui/prefdlg.ui" line="242"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;&lt;span style=&quot; font-size:7pt;&quot;&gt;KSoft development&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PrefDlgImpl</name>
    <message>
        <location filename="../prefdlgimpl.cpp" line="71"/>
        <source>Name currency</source>
        <translation>Valute Name</translation>
    </message>
    <message>
        <location filename="../prefdlgimpl.cpp" line="71"/>
        <source>Rate</source>
        <translation>Kurs</translation>
    </message>
    <message>
        <location filename="../prefdlgimpl.cpp" line="213"/>
        <source>Fatal error</source>
        <translation>Fataler Fehler</translation>
    </message>
    <message>
        <location filename="../prefdlgimpl.cpp" line="213"/>
        <source>Database currency is corrupted.</source>
        <translation>Basis der Angaben der Währung ist angebrochen.</translation>
    </message>
    <message>
        <location filename="../prefdlgimpl.cpp" line="192"/>
        <source>Error password</source>
        <translation>Parole Fehler</translation>
    </message>
    <message>
        <location filename="../prefdlgimpl.cpp" line="186"/>
        <source>Old password is incorrect.</source>
        <translation>Alte parole ist Fehler.</translation>
    </message>
    <message>
        <location filename="../prefdlgimpl.cpp" line="192"/>
        <source>Passwords is not equable..</source>
        <translation>Parolen nicht zusammenfallen.</translation>
    </message>
    <message>
        <location filename="../prefdlgimpl.cpp" line="230"/>
        <source>Currency</source>
        <translation>Valuta</translation>
    </message>
    <message>
        <location filename="../prefdlgimpl.cpp" line="231"/>
        <source>Currency &lt;b&gt;%1&lt;/b&gt; is really exist</source>
        <translation>Valuta &lt;b&gt;%1&lt;/b&gt;  ist schon sein</translation>
    </message>
    <message>
        <location filename="../prefdlgimpl.cpp" line="247"/>
        <source>Delete cash</source>
        <translation>Entfernen Valute</translation>
    </message>
    <message>
        <location filename="../prefdlgimpl.cpp" line="248"/>
        <source>Confirm delete currency &lt;b&gt;%1&lt;/b&gt;?</source>
        <translation>Bestärkung der Abkehr der Währung &lt;b&gt;%1&lt;/b&gt;?</translation>
    </message>
    <message>
        <location filename="../prefdlgimpl.cpp" line="133"/>
        <source>Password</source>
        <translation>Parole</translation>
    </message>
</context>
<context>
    <name>PrintDialog</name>
    <message>
        <location filename="../finances.cpp" line="40"/>
        <source>Print..</source>
        <translation>Druck..</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="41"/>
        <source>Print preview..</source>
        <translation>Druck Sichtung..</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="42"/>
        <source>Save to file..</source>
        <translation>Speichern an file..</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="43"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="45"/>
        <source>Save with images</source>
        <translation>Mit Zeichnungen zu behalten</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="69"/>
        <source>Preview to print</source>
        <translation>Druck Sichtung</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="102"/>
        <source>Print report</source>
        <translation>Druck</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="116"/>
        <source>Save report...</source>
        <translation>Speichern...</translation>
    </message>
    <message>
        <location filename="../finances.cpp" line="117"/>
        <source>HTML-Files (*.htm *.html)</source>
        <translation>HTML-datei (*.htm *.html)</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../fdatabase.cpp" line="176"/>
        <source>No transactions</source>
        <translation>Operation auf gegebenes Jahr ist keinen</translation>
    </message>
    <message>
        <location filename="../fdatabase.cpp" line="347"/>
        <source>Erorr operation</source>
        <translation>Operation Fehler</translation>
    </message>
    <message>
        <location filename="../fdatabase.cpp" line="347"/>
        <source>No cash</source>
        <translation>Geld gibt es keinen</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="32"/>
        <source>Unable to establish a database connection.</source>
        <translation>Fehler Vereinigen.</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="35"/>
        <source>QFinances needs SQLite support. Please read the Qt SQL driver documentation for information how to build it.</source>
        <translation>Programme ist brauchen SQLite. Lessen die Dokumentation über Qt SQL-Treiber machen zu Unterstützung.</translation>
    </message>
    <message>
        <location filename="../misc.cpp" line="55"/>
        <source>Access denieded. Password incorrect</source>
        <translation>In Eingang es ist abgesagt. Parolet ist unrichtig</translation>
    </message>
    <message>
        <location filename="../fdatabase.cpp" line="392"/>
        <source>Credit amortiazation</source>
        <translation>Tilgung des Kredits</translation>
    </message>
    <message>
        <location filename="../fdatabase.cpp" line="392"/>
        <source>debtor</source>
        <translation>Schuldner</translation>
    </message>
    <message>
        <location filename="../fdatabase.cpp" line="396"/>
        <source>Cash automatically converted: from</source>
        <translation>Bestand automatisch ist konvertiert in: aus</translation>
    </message>
    <message>
        <location filename="../fdatabase.cpp" line="661"/>
        <source>to</source>
        <translation>bis</translation>
    </message>
    <message>
        <location filename="../fdatabase.cpp" line="660"/>
        <source>Change currency bank from</source>
        <translation>Änderung der Währung in Bank aus</translation>
    </message>
    <message>
        <location filename="../filterdlgimpl.cpp" line="27"/>
        <source>Column</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <location filename="../filterdlgimpl.cpp" line="28"/>
        <source>Condition1</source>
        <translation>Bedingung1</translation>
    </message>
    <message>
        <location filename="../filterdlgimpl.cpp" line="29"/>
        <source>Pattern1</source>
        <translation>Vorbild1</translation>
    </message>
    <message>
        <location filename="../filterdlgimpl.cpp" line="30"/>
        <source>Condition2</source>
        <translation>Bedingung2</translation>
    </message>
    <message>
        <location filename="../filterdlgimpl.cpp" line="31"/>
        <source>Pattern2</source>
        <translation>Vorbild2</translation>
    </message>
</context>
<context>
    <name>cash_form</name>
    <message>
        <location filename="../ui/cash_form.ui" line="17"/>
        <source>Home Bank</source>
        <translation>Hausesbank</translation>
    </message>
    <message>
        <location filename="../ui/cash_form.ui" line="38"/>
        <source>Bank cash</source>
        <translation>Gelder in Bank</translation>
    </message>
    <message>
        <location filename="../ui/cash_form.ui" line="72"/>
        <source>Income</source>
        <translation>Profit</translation>
    </message>
    <message>
        <location filename="../ui/cash_form.ui" line="128"/>
        <source>Preview cash in:</source>
        <translation>Bestand in zu Einsicht:</translation>
    </message>
    <message>
        <location filename="../ui/cash_form.ui" line="161"/>
        <source>Currency converter</source>
        <translation>Konverter der Währung</translation>
    </message>
    <message>
        <location filename="../ui/cash_form.ui" line="194"/>
        <source>Unit:</source>
        <translation>Einer:</translation>
    </message>
    <message>
        <location filename="../ui/cash_form.ui" line="104"/>
        <source>Expense</source>
        <translation>Ausgabe</translation>
    </message>
</context>
<context>
    <name>parameter_dlg</name>
    <message>
        <location filename="../prefdlgimpl.cpp" line="12"/>
        <source>New currency</source>
        <translation>Neue Valuta</translation>
    </message>
    <message>
        <location filename="../prefdlgimpl.cpp" line="13"/>
        <source>OK</source>
        <translation>ОК</translation>
    </message>
    <message>
        <location filename="../prefdlgimpl.cpp" line="14"/>
        <source>Cancel</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location filename="../prefdlgimpl.cpp" line="17"/>
        <source>Name currency:</source>
        <translation>Valute Name:</translation>
    </message>
    <message>
        <location filename="../prefdlgimpl.cpp" line="18"/>
        <source>Rate:</source>
        <translation>Kurs:</translation>
    </message>
    <message>
        <location filename="../prefdlgimpl.cpp" line="43"/>
        <source>Change currency rate</source>
        <translation>Abwandelt Währung der Kurs</translation>
    </message>
</context>
</TS>
