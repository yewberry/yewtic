#include "topheader.h"

#include <QtGui>

topHeader::topHeader(QWidget *p)
        :QWidget(p)
{
    setFixedHeight(200);
}

void topHeader::paintEvent ( QPaintEvent * /*event*/ )
{
        QPainter p(this);
        p.fillRect(rect(), QBrush(qApp->palette().window() ));

        QLinearGradient headerBackgroundGrd(0,0, 0,100);

        headerBackgroundGrd.setColorAt(0, QColor(115,115,115));
        headerBackgroundGrd.setColorAt(1, QColor(65,65,65));
        //headerBackgroundGrd.setColorAt(0, QColor(252,252,252));
        //headerBackgroundGrd.setColorAt(0.5, QColor(220,220,220));
        //headerBackgroundGrd.setColorAt(0.51, QColor(193,193,193));
        //headerBackgroundGrd.setColorAt(1, QColor(225,225,225));
        //headerBackgroundGrd.setColorAt(0, QColor(200,201,201));
        //headerBackgroundGrd.setColorAt(1, QColor(128,128,131));

        p.fillRect(QRect(0,0,width(),200), QBrush(headerBackgroundGrd));
        p.drawPixmap(0,0,QPixmap(":/img/Logom.png"));
}
