#ifndef PREFDLGIMPL_H
#define PREFDLGIMPL_H

#include <QDialog>

class QLineEdit;

class parameter_dlg : public QDialog
{
Q_OBJECT
public:
    parameter_dlg(QWidget *parent=0);
    void set_data(const QString& name, const QString& rate);
    bool get_data(QString& name, QString& rate);
private:
    QLineEdit *ename;
    QLineEdit *erate;
};

#include "ui_prefdlg.h"

//const char* company  = "udl";
//const char* programm = "myfinances";

class PrefDlgImpl : public QDialog, public Ui::PrefDlg
{
    Q_OBJECT
public:
    PrefDlgImpl(bool bfirst_show=false, QWidget *parent=0);
private slots:
    void slot_ok();
    void slot_add();
    void slot_rem();
    void slot_ch();
public slots:
    void slot_set_main();
private:
    bool bfirst;
    QString old_lang;
public:
       static const char* company;
       static const char* key;

};

#endif // PREFDLGIMPL_H
