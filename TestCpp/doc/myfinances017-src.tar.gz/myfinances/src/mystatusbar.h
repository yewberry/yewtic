#ifndef MYSTATUSBAR_H
#define MYSTATUSBAR_H

#include <QStatusBar>

class myStatusBar : public QStatusBar
{
public:
    myStatusBar();
protected:
        void paintEvent ( QPaintEvent * event );
};

#endif // MYSTATUSBAR_H
