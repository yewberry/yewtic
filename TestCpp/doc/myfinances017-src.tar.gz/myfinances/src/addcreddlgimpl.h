//
// C++ Interface: addcreddlgimpl
//
// Description: 
//
//
// Author: peter komar <peter@linux-nlyt>, (C) 2008
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef ADDCREDDLGIMPL_H
#define ADDCREDDLGIMPL_H

#include <QDialog>
#include "ui_addcredit.h"

QT_FORWARD_DECLARE_CLASS(Db_dat);

/**
	@author peter komar <peter@linux-nlyt>
*/
class AddCredDlgImpl : public QDialog, public Ui::AddCredDlg
{
Q_OBJECT
public:
    AddCredDlgImpl(QWidget *parent = 0);

    ~AddCredDlgImpl();
    bool is_exit();
    void set_info_data(const QString& sdata);
    Db_dat get_data();

protected:
    bool b_Ex;
private slots:
    void slot_ok();
    void slot_cancel();
};

#endif
