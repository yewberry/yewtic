//
// C++ Interface: newopdlgimpl
//
// Description: 
//
//
// Author: peter komar <peter@linux-nlyt>, (C) 2008
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef NEWOPDLGIMPL_H
#define NEWOPDLGIMPL_H

#include <QDialog>
#include "ui_newop.h"

/**
	@author peter komar <peter@linux-nlyt>
*/
class NewOpDlgImpl : public QDialog, public Ui::NewopDlg
{
Q_OBJECT
public:
    NewOpDlgImpl(QWidget *parent = 0);

    ~NewOpDlgImpl();
    bool get_bAdd();
    bool b_Ex;

protected:
    int bAdd;
private slots:
    void slot_bAdd();
public slots:
    void slot_exit();
};

#endif
