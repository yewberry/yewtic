#include "mystatusbar.h"

#include <QtGui>

myStatusBar::myStatusBar()
{
}

void myStatusBar::paintEvent ( QPaintEvent * )
{
    QPainter p(this);
        p.fillRect(rect(), QBrush(qApp->palette().window() ));

        QLinearGradient headerBackgroundGrd(0,0, 0,100);
        headerBackgroundGrd.setColorAt(0, QColor(100,100,100));
        headerBackgroundGrd.setColorAt(1, QColor(111,111,111));

        p.fillRect(QRect(0,0,width(),height()), QBrush(headerBackgroundGrd));
}
