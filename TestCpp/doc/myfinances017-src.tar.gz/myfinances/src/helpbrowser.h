//
// C++ Interface: helpbrowser
//
// Description: 
//
//
// Author: Peter <marcusk@i.ua>, (C) 2009
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef HELPBROWSER_H
#define HELPBROWSER_H

#include <QWidget>

class QPushButton;
class QTextBrowser;
/**
	@author Peter <marcusk@i.ua>
*/
class HelpBrowser : public QWidget
{
Q_OBJECT
public:
    HelpBrowser(QWidget* parent = 0);

    ~HelpBrowser();
    void reload_ui();
	void load_source(const QString& name);
private:
    QPushButton *pcmdHome;
	QTextBrowser *ptxtBrowser;
};

#endif
