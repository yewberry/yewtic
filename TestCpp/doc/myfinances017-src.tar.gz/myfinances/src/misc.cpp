#include "misc.h"
#include "fdatabase.h"
#include <QSqlDatabase>
#include <QMessageBox>
#include <QDebug>
#include <QFile>

//

//btype - connect to account or currency
bool connectDB(QString const& dbName, const QString& user, const QString& passwrd, bool btype)
{
	QSqlDatabase database;
	
	if( QSqlDatabase::database().databaseName() != dbName )
	//if( QSqlDatabase::database().connectionName () != dbName )
	{
		database = QSqlDatabase::addDatabase("QSQLITE", dbName);
		database.setDatabaseName(dbName);
		database.setUserName(user);
		database.setPassword(passwrd);
	}
	else
	{
		database = QSqlDatabase::database();
		if ( database.isOpen() )
			return true;
	}
	//
	if (!database.open()) {
		QMessageBox::critical(0, "QFinances",
				      QObject::tr("Unable to establish a database connection.")+"\n"+
						      QObject::tr("QFinances needs SQLite support. Please read "
						      "the Qt SQL driver documentation for information how "
						      "to build it."), QMessageBox::Cancel,
	    QMessageBox::NoButton);
		
		database = QSqlDatabase();
		QSqlDatabase::removeDatabase(dbName);
				
		return false;
	}

	//if(QFile::exists(dbName))
	//	return true;
	QStringList tabl = database.tables(); //get count tables database
	
		
	if(btype)
	{
		if(tabl.size() == 3)
		{
			if(!check_password(dbName,passwrd))
			{
				QMessageBox::critical(0, "QFinances",QObject::tr("Access denieded. Password incorrect"));
				return false;
			}
			
			return true;
		}

		if(!create_db_accounts(dbName,passwrd))
		     return false;
	}
	else
	{
		if(tabl.size() == 2)
			return true;
		
		if(!create_db_cash_rate(dbName))
			return false;
	}
	
	
    return true;
}

QString stringFromResource(const QString &resName)
{
	QFile file(resName);
	file.open(QIODevice::ReadOnly | QIODevice::Text);
	QTextStream ts(&file);
	return ts.readAll();
}

//
