/***************************************************************************
 *   Copyright (C) 2007 by peter komar   *
 *   marcusk@i.ua   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "mdialogimpl.h"

#include <QtGui>
#include <QApplication>

MDialogImpl::MDialogImpl( QWidget *parent)
        :QDialog(parent), bc(false), bnew(false)
{
    setupUi(this);

    label1->setText(tr("Acount"));
    label2->setText(tr("Password"));
    lineEdit1->setEchoMode(QLineEdit::Password);
    comboBox->setEditable(false);
	
    setWindowTitle(tr("Authorization"));
    setWindowIcon(QIcon(":/img/password.png"));

    okBtn->setText(tr("Login"));
    cancelBtn->setText(tr("Exit"));
    
    connect(okBtn, SIGNAL(clicked()), this, SLOT(slot_ok()));
    connect(cancelBtn, SIGNAL(clicked()), this, SLOT(slot_cancel()));
    connect(chNewAc, SIGNAL(clicked(bool )),this, SLOT(setEditable(bool)));
}


bool MDialogImpl::get_data(QString& value1, QString& value2)
{
    value1 = comboBox->currentText();
    value2 = lineEdit1->text();

    return bc;
}

void MDialogImpl::slot_ok()
{
    bc = false;
    QString s;
    
    s = comboBox->currentText();
    s = s.simplified();
    
    if(s == "")
    {
        QMessageBox::information(0,tr("Information"), tr("Please enter name account."));
        return;
    }

    if(bnew)
    {
      if(QFile::exists(QApplication::applicationDirPath()+"/"+comboBox->currentText()+".db"))
      {
	    QMessageBox::information(0,tr("Information"), tr("Account is exist."));
	    return;
      }
      
    }

    accept();
}

void MDialogImpl::slot_cancel()
{
    bc = true;

    reject();
}

void MDialogImpl::closeEvent(QCloseEvent *event)
{
	bc = true;
	event->accept();
}


/*!
    \fn MDialogImpl::setEditable(bool )
 */
void MDialogImpl::setEditable(bool b)
{
        comboBox->setEditable(b);
        lineEdit1->setVisible(!b);
		label2->setVisible(!b);
        comboBox->setEditText("");
        if(b)
           comboBox->setFocus();
	bnew = b;

}
