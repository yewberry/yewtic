//
// C++ Interface: dockwidg
//
// Description: 
//
//
// Author: peter komar <peter@linux-nlyt>, (C) 2008
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef DOCKWIDG_H
#define DOCKWIDG_H

#include <QWidget>
#include <QDialog>

class QTreeWidget;
class QPushButton;

/**
	@author peter komar <peter@linux-nlyt>
*/
class DockWidg : public QDialog
{
Q_OBJECT
public:
    DockWidg(QWidget *parent = 0);

    ~DockWidg();
    void load_data();
    void reload_ui();

    QTreeWidget *listCred;
    QPushButton *NewBtn;
    QPushButton *infBtn;
    QPushButton *RemBtn;
};

#endif
