//
// C++ Interface: qerytable
//
// Description: 
//
//
// Author: Peter <marcusk@i.ua>, (C) 2009
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef QERYTABLE_H
#define QERYTABLE_H

#include <QTreeView>

/**
	@author Peter <marcusk@i.ua>
*/
class QeryTable : public QTreeView
{
Q_OBJECT
public:
     QeryTable(QWidget *parent = 0 );

    ~QeryTable();
    void setSourceModel(QAbstractItemModel *model);
protected:
    void drawRow(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const;

};

#endif
