//
// C++ Implementation: addcreddlgimpl
//
// Description: 
//
//
// Author: peter komar <peter@linux-nlyt>, (C) 2008
//
// Copyright: See COPYING file that comes with this distribution
//
//
#include "addcreddlgimpl.h"
#include "fdatabase.h"

#include <QMessageBox>

AddCredDlgImpl::AddCredDlgImpl(QWidget *parent)
 : QDialog(parent)
{
	setupUi(this);
	
	b_Ex=false;
        dateTimeEdit->setMinimumDate(QDate::currentDate().addDays(-365));
	dateTimeEdit->setMaximumDate(QDate::currentDate().addDays(365));
	
	dateTimeEdit->setMinimumTime(QTime::currentTime().addMSecs(70));
	dateTimeEdit->setMaximumTime(QTime::currentTime().addMSecs(70));
	
	dateTimeEdit->setDateTime(QDateTime::currentDateTime());
	
	dateTimeEdit->setDisplayFormat(get_display_format());
	groupBox->setShown(false);
	
	QString name_currency;
	double d;
	get_data_from_bank(d, name_currency);
	
	count_cr->setSuffix(name_currency);
	
	connect(okBtn, SIGNAL(clicked()), this, SLOT(slot_ok()));
        connect(canBtn, SIGNAL(clicked()), this, SLOT(slot_cancel()));
}


AddCredDlgImpl::~AddCredDlgImpl()
{
}




/*!
    \fn AddCredDlgImpl::is_exit()
 */
bool AddCredDlgImpl::is_exit()
{
    return b_Ex;
}


/*!
    \fn AddCredDlgImpl::slot_ok()
 */
void AddCredDlgImpl::slot_ok()
{
    double d = count_cr->value();
    
    if(!d)
    {
        QMessageBox::information(this,tr("info"),tr("Please enter count mortgagor"));
	return;
    }
    
    QString s = name_debtor_e->text();
    if(s.isEmpty())
    {
            QMessageBox::information(this,tr("info"),tr("Please enter name mortgagor"));
	    return;
    }
    accept();
}


/*!
    \fn AddCredDlgImpl::slot_cancel()
 */
void AddCredDlgImpl::slot_cancel()
{
	b_Ex = true;
	
	reject();
}


/*!
    \fn AddCredDlgImpl::set_info_data(const Db_dat& data)
 */
void AddCredDlgImpl::set_info_data(const QString& sdata)
{
	Db_dat data = info_creditor(sdata);
        dateTimeEdit->setDateTime(QDateTime::fromString(data.date,get_display_format()));
	name_debtor_e->setReadOnly(TRUE);
	count_cr->setReadOnly(TRUE);
	textEdit->setReadOnly(TRUE);
	okBtn->setVisible(FALSE);
        percent_spin->setVisible(FALSE);
	label_3->setVisible(FALSE);

	canBtn->setText(tr("Close"));
	
        setWindowTitle(tr("Info mortgagor"));
		
	name_debtor_e->setText(data.Name);
	count_cr->setSuffix(data.currency);
	count_cr->setValue(data.count_d);
	textEdit->setText(data.descr);
	//percent_spin->setValue(data.percent);
	
	if(data.type == "Year")
	   typeBox->setCurrentIndex(1);
	else
	   typeBox->setCurrentIndex(0);
}


/*!
    \fn AddCredDlgImpl::get_data()
 */
Db_dat AddCredDlgImpl::get_data()
{
	Db_dat data;
	data.date = dateTimeEdit->dateTime().toString(get_display_format());
	data.date_incr = data.date;
	data.count_d = count_cr->value();
	data.Name = name_debtor_e->text();
	data.currency = count_cr->suffix();
	int i = percent_spin->value();
	double res = (double)data.count_d*i/100;//calculate parcent
	data.percent = res;
	
	QString s = typeBox->currentText();
	
	if(s == tr("Year"))
		s = "Year";
	else
		s = "Month";
	data.type = s;
	
	s = textEdit->toPlainText();
	QString s_h = "<b>%1</b> <b>%2:</b>";
	
	QString format = s_h.arg(tr("Credit")).arg(tr("debtor"))
			+data.Name+QString("<br><font color=\"blue\"><b>%1:</b></font><br>")
			.arg(tr("Info"))+" "
			+QString("<b>%1:</b> %2<br><b>%3:</b> %4 %<br><b>%5:</b> %6")
			.arg(tr("Percent stake")).arg(QString::number(res,'g'))
			.arg(tr("Percent")).arg(QString::number(i))
			.arg(tr("Count borrowing")).arg(QString::number(data.count_d,'F',2))
			+" "+data.currency+"<br>";
	if(!s.isEmpty())
		format += QString("<b>%1:</b> %2").arg(tr("Note")).arg(s);
	data.descr = format;		
	
	return data;
}
