//
// C++ Implementation: filterdlgimpl
//
// Description: 
//
//
// Author: Peter <marcusk@i.ua>, (C) 2009
//
// Copyright: See COPYING file that comes with this distribution
//
//
#include "filterdlgimpl.h"
#include "fdatabase.h"

#include <QtGui>

FilterDlgImpl::FilterDlgImpl(QWidget* parent)
	: QDialog(parent), baccept(false)
{
	setupUi(this);
	
	Qeryt->setRootIsDecorated(false);
        Qeryt->setSelectionMode(QAbstractItemView::NoSelection);
	
	QStandardItemModel *model = new QStandardItemModel(0, 5, this);

	model->setHeaderData(0, Qt::Horizontal, QObject::tr("Column"));
	model->setHeaderData(1, Qt::Horizontal, QObject::tr("Condition1"));
	model->setHeaderData(2, Qt::Horizontal, QObject::tr("Pattern1"));
	model->setHeaderData(3, Qt::Horizontal, QObject::tr("Condition2"));
	model->setHeaderData(4, Qt::Horizontal, QObject::tr("Pattern2"));
	
	model->insertRow(0);
	model->insertRow(1);
	model->insertRow(2);
	model->setData(model->index(0, 0), tr("Date"));
	model->setData(model->index(0, 1), "=");
	model->setData(model->index(1, 0), tr("Count"));
	model->setData(model->index(1, 1), "=");
	model->setData(model->index(2, 0), tr("Description"));
		
	Qeryt->setModel(model);
		
	setMinimumSize(680,100);	
	connect(filterBtn, SIGNAL(clicked()),this,SLOT(slot_filter()));
}


FilterDlgImpl::~FilterDlgImpl()
{
}

/*!
    \fn FilterDlgImpl::slot_filter()
 */
void FilterDlgImpl::slot_filter()
{
	/*int flags = 0;
	flags |= (date_check->isChecked()) << 1;
	if(date_check->isChecked())
	   flags |= (whole_check_date->isChecked()) << 2;
	
	flags |= (count_check->isChecked()) << 3;
	if(count_check->isChecked())
	{
	    s = comboBox1->currentText();
	    
	    if(s == "<")
		    flags |= 1 << 4;
	    else if(s == "<=")
		    flags |= 1 << 5;
	    else if(s == ">")
		    flags |= 1 << 6;
	    else if(s == ">=")
		    flags |= 1 << 7;
	    else if(s == "=")
		    flags |= 1 << 8;
	    s = comboBox2->currentText();
	    
	    if(!s.isEmpty() && !linefind2->text().isEmpty())
	    {
		 if(s == "<")
		    flags |= 1 << 9;
	         else if(s == "<=")
		    flags |= 1 << 10;
	         else if(s == ">")
		    flags |= 1 << 11;
	         else if(s == ">=")
		    flags |= 1 << 12;
	    }
	}
	*/
	
	QStandardItemModel* model = (QStandardItemModel*)Qeryt->model();
	
	QString qery, sCondition1;
	int icur = combo_type->currentIndex();
	
	if( icur == 1 )
		qery = "(type_op like 'income')";
	else if( icur == 2 )
		qery += " and (type_op like 'outgoes')";
	
	     //get date item
	     sCondition1 = model->data(model->index(0,1), Qt::EditRole).toString();
	     QString sPattern1 = model->data(model->index(0,2), Qt::EditRole).toString();
	     QString sCondition2 = model->data(model->index(0,3), Qt::EditRole).toString();
	     QString sPattern2 = model->data(model->index(0,4), Qt::EditRole).toString();
	     sCondition1 = sCondition1.simplified();
	     sCondition2 = sCondition2.simplified();
	     sPattern2 = sPattern2.simplified();
	     sPattern1 = sPattern1.simplified();
	     
	     if((sCondition2 == ">") || (sCondition2 == "<="))
	          sPattern2 += " 23:59";
	     else
		  sPattern2 += " 00:00";
	     
	     if((sCondition1 == ">") || (sCondition1 == "<="))
	          sPattern1 += " 23:59";
	     else
		  sPattern1 += " 00:00";
	     
	     sPattern2 = convert_date_format(sPattern2, false);
	     sPattern1 = convert_date_format(sPattern1, false);
	     
	
	     if(!sPattern1.isEmpty())
	     {
		     qery += form_qery(sCondition1, sPattern1, "date_s");
	     }
	     
	     if((!sPattern2.isEmpty()) && (!sCondition2.isEmpty()) && (sCondition1 != "="))
	     {
		     qery += form_qery(sCondition2, sPattern2, "date_s");
	     }
	     
	     sCondition1 = model->data(model->index(1,1), Qt::EditRole).toString();
	     sPattern1 = model->data(model->index(1,2), Qt::EditRole).toString();
	     sCondition2 = model->data(model->index(1,3), Qt::EditRole).toString();
	     sPattern2 = model->data(model->index(1,4), Qt::EditRole).toString();
	     sCondition1 = sCondition1.simplified();
	     sCondition2 = sCondition2.simplified();
	     sPattern2 = sPattern2.simplified();
	     sPattern1 = sPattern1.simplified();
	     
	     if(!sPattern1.isEmpty())
	     {
		     qery += form_qery(sCondition1, sPattern1, "count");
	     }
	     
	     if((!sPattern2.isEmpty()) && (!sCondition2.isEmpty()) && (sCondition1 != "="))
	     {
		     qery += form_qery(sCondition2, sPattern2, "count");
	     }
	     
	     sPattern1 = model->data(model->index(2,1), Qt::EditRole).toString();
	     if(!sPattern1.isEmpty())
		     qery += " and (description like '%"+sPattern1+"%')";
	     
	     if(qery.left(4) == " and")
		qery.remove(0,5);
	     
	     qery_string = qery;

	     baccept = true;
	
	accept();
}

/*!
    \fn FilterDlgImpl::form_qery(const QString& str1, const QString& str2)
 */
QString FilterDlgImpl::form_qery(const QString& str1, const QString& str2, const QString& patt)
{
	char c = '\'';
	
	if(patt == "count")
		c = ' ';
	
	QString sRet;
	if(str1 == ">")
		sRet += " and ("+patt+" > "+c+str2+c+")";
	else if(str1 == ">=")
		sRet += " and ("+patt+" >= "+c+str2+c+")";
	else if(str1 == "<")
		sRet += " and ("+patt+" < "+c+str2+c+")";
	else if(str1 == "<=")
		sRet += " and ("+patt+" <= "+c+str2+c+")";
	else if((str1 == "=") && (patt == "count"))
		sRet += " and ("+patt+" = "+str2+")";
	else if((str1 == "=") && (patt == "date_s"))
	{
		QString s = str2;
		s.remove(" 00:00");
		sRet += " and ("+patt+" like '"+s+" __:__')";
	}
	
	return sRet;
}


/*!
    \fn FilterDlgImpl::get_filter_data()
 */
QString FilterDlgImpl::get_filter_data()
{
	if(!baccept)
		return QString("");
	
	if(qery_string.isEmpty())
		qery_string = " 1";
	
	return qery_string;
}
// 



