//
// C++ Interface: filterdlgimpl
//
// Description: 
//
//
// Author: Peter <marcusk@i.ua>, (C) 2009
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef FILTERDLGIMPL_H
#define FILTERDLGIMPL_H

#include <QDialog>
#include <QString>
#include "ui_filterdialog.h"

/**
	@author Peter <marcusk@i.ua>
*/
class FilterDlgImpl : public QDialog, public Ui::FilterDlg
{
Q_OBJECT
public:
    FilterDlgImpl(QWidget* parent=0);

    ~FilterDlgImpl();
    QString get_filter_data();

private slots:
    void slot_filter();
 
private:
   // int filterFlags;
   QString qery_string;
   bool baccept;

private:
    QString form_qery(const QString& str1, const QString& str2, const QString& patt);
};

#endif
