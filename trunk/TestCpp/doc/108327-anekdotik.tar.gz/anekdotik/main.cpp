
#include <QtGui>

#include "anekdotik.h"

int main(int argc, char *argv[]){

    QApplication app(argc, argv);
    QApplication::setStyle(new QCleanlooksStyle);
    anekdotik form1;
    form1.show();

    return app.exec();

}
