#ifndef ANEKDOTIK_H
#define ANEKDOTIK_H

#include <QtGui>
#include <Qt/qhttp.h>

class anekdotik : public QWidget {
	Q_OBJECT
    public:
	anekdotik(QWidget *parent = 0);    

    private:
	QPixmap pic;
	int MouseStartPosX;
	int MouseStartPosY;
	QLabel *LabelName;
	QLabel *ButtonExit;
	QLabel *ButtonNext;
        QTextEdit *textEdit;
        QHttp *http;
	
	void btnNext();
	
    protected:
	void resizeEvent(QResizeEvent */*e*/);
	void paintEvent(QPaintEvent *e);
	void mousePressEvent(QMouseEvent *event);
        void mouseMoveEvent(QMouseEvent *event);
        bool eventFilter(QObject*, QEvent *);
	void keyPressEvent(QKeyEvent *event);

    private slots:
	void RefreshAnek();
        	
};

#endif
